package com.voicepower

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.firebase.messaging.FirebaseMessaging
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private enum class UiState { IDLE, HANDLE, SHEET, DOCK }

    private var state = UiState.IDLE
    private var current: PowerEvent? = null      // রেকর্ড স্ক্রিনে যে ইভেন্ট বাছা হয়েছে
    private var recorder: MediaRecorder? = null
    private var recording = false
    private var haveTmp = false                  // রেকর্ড হয়েছে কিন্তু এখনও সেভ হয়নি
    private var secs = 0
    private var tmpPlayer: MediaPlayer? = null
    private var playingRow: PowerEvent? = null
    private var pendingRecord: PowerEvent? = null
    private var pendingPick: PowerEvent? = null
    private val rowViews = mutableMapOf<PowerEvent, View>()
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var stage: View
    private lateinit var idleGroup: View
    private lateinit var dockGroup: View
    private lateinit var listPane: View
    private lateinit var rowsBox: LinearLayout
    private lateinit var listHeader: TextView
    private lateinit var orbFrame: View
    private lateinit var orbRing: View
    private lateinit var orbRing2: View
    private lateinit var orbCore: View
    private lateinit var eventPill: TextView
    private lateinit var dockHint: TextView
    private lateinit var statusView: TextView
    private lateinit var wave: LinearLayout
    private lateinit var btnRec: MaterialButton
    private lateinit var btnSave: MaterialButton
    private lateinit var btnFile: MaterialButton
    private var tmpSource = "rec"
    private lateinit var btnBattery: Button
    private lateinit var summary: TextView
    private lateinit var scrim: View
    private lateinit var sheet: ScrollView
    private lateinit var sheetList: LinearLayout
    private lateinit var handle: View
    private lateinit var handleRing: View
    private lateinit var handleOrbit: View
    private lateinit var handleGlow: View
    private lateinit var introHint: TextView
    private lateinit var nextHint: TextView

    private val waveBars = mutableListOf<View>()
    private val waveAnims = mutableListOf<ObjectAnimator>()
    private var orbPulse: ObjectAnimator? = null
    private var orbPulse2: ObjectAnimator? = null
    private var handleOrbitAnim: ObjectAnimator? = null
    private var handleGlowAnim: ObjectAnimator? = null
    private val blobAnims = mutableListOf<ObjectAnimator>()
    private var orbBreath: ObjectAnimator? = null
    private var ringSpin: ObjectAnimator? = null
    private var bob: ObjectAnimator? = null
    private var introNudge: ObjectAnimator? = null
    private var idleBreath: ObjectAnimator? = null
    private var idleGlow: ObjectAnimator? = null
    private lateinit var idleRing: View
    private lateinit var idleRing2: View
    private lateinit var idleCore: View

    private val tick = object : Runnable {
        override fun run() {
            if (!recording) return
            secs++
            setStatus("রেকর্ডিং চলছে…  " + fmt(secs), false)
            ui.postDelayed(this, 1000)
        }
    }

    private val hideIntroRun = Runnable { hideIntro() }
    private val hideNextRun = Runnable {
        nextHint.animate().alpha(0f).setDuration(300).withEndAction { nextHint.visibility = View.GONE }.start()
    }

    private val pickAudio =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val e = pendingPick
            if (uri != null && e != null) importFile(e, uri)
        }

    private val pickDockAudio =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val e = current
            if (uri != null && e != null && state == UiState.DOCK) importToTmp(e, uri)
        }

    // ফাইল বেছে নিলে সরাসরি সেভ না হয়ে আগে শোনা যায়, তারপর সেভ বাটনে সেভ হয়
    private fun importToTmp(e: PowerEvent, uri: Uri) {
        val tmp = VoiceStore.tempFile(this, e)
        try {
            stopTmp()
            contentResolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { out -> input.copyTo(out) }
            } ?: throw IllegalStateException("open failed")
            haveTmp = tmp.exists() && tmp.length() > 0
            tmpSource = displayName(uri)
            setStatus("", true)
            updateRecButton()
            updateSaveButton()
        } catch (ex: Exception) {
            tmp.delete()
            toast("ফাইলটি পড়া যায়নি")
        }
    }

    private var onServiceAccountPicked: (() -> Unit)? = null

    private val pickServiceAccount =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@registerForActivityResult
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                if (RemotePush.isValidServiceAccount(text)) {
                    RemotePush.setServiceAccount(this, text)
                    toast("ফাইল বসেছে")
                    onServiceAccountPicked?.invoke()
                } else toast("এটা সঠিক সার্ভিস অ্যাকাউন্ট ফাইল না")
            } catch (ex: Exception) {
                toast("ফাইল পড়া যায়নি")
            }
        }

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            val e = pendingRecord
            if (ok && e != null) startRecording(e)
            else toast("মাইক্রোফোনের অনুমতি ছাড়া রেকর্ড করা যাবে না")
        }

    private var onEmgPermResult: ((Boolean) -> Unit)? = null

    private val emgPermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            onEmgPermResult?.invoke(Emergency.hasPermissions(this))
        }

    /** সার্ভিসকে জানায় জরুরি সেটিং বদলেছে (মিডিয়া সেশন ও ফোরগ্রাউন্ড টাইপ নতুন করে বসবে) */
    private fun refreshService() {
        try {
            ContextCompat.startForegroundService(
                this, Intent(this, PowerService::class.java).setAction(PowerService.ACTION_REFRESH)
            )
        } catch (_: Exception) {}
    }

    private val btPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { askBatteryOnce() }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startEngine() }

    // ---------- ছোট সহায়ক ----------

    private fun dp(v: Int): Float = v * resources.displayMetrics.density
    private fun dpi(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun bnStr(s: String): String =
        s.map { if (it in '0'..'9') "০১২৩৪৫৬৭৮৯"[it - '0'] else it }.joinToString("")

    private fun bn(n: Int): String = bnStr(n.toString())

    private fun fmt(s: Int): String = bnStr((s / 60).toString() + ":" + (s % 60).toString().padStart(2, '0'))

    private fun savedEvents(): List<PowerEvent> =
        PowerEvent.values().filter { VoiceStore.hasVoice(this, it) }

    private fun color(id: Int) = ContextCompat.getColor(this, id)

    private fun setStatus(t: String, ok: Boolean) {
        statusView.text = t
        statusView.visibility = if (t.isEmpty()) View.GONE else View.VISIBLE
        statusView.setTextColor(color(if (ok) R.color.green else R.color.sub))
    }

    // ---------- শুরু ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // অ্যাপ খোলা থাকলে ফোনের ভলিউম বাটন মিডিয়া (ভয়েস) ভলিউম বাড়াবে-কমাবে
        volumeControlStream = AudioManager.STREAM_MUSIC

        stage = findViewById(R.id.stage)
        idleGroup = findViewById(R.id.idleGroup)
        idleRing = findViewById(R.id.idleRing)
        idleRing2 = findViewById(R.id.idleRing2)
        idleCore = findViewById(R.id.idleCore)
        dockGroup = findViewById(R.id.dockGroup)
        listPane = findViewById(R.id.listPane)
        rowsBox = findViewById(R.id.rows)
        listHeader = findViewById(R.id.listHeader)
        orbFrame = findViewById(R.id.orbFrame)
        orbRing = findViewById(R.id.orbRing)
        orbRing2 = findViewById(R.id.orbRing2)
        orbCore = findViewById(R.id.orbCore)
        eventPill = findViewById(R.id.eventPill)
        dockHint = findViewById(R.id.dockHint)
        statusView = findViewById(R.id.status)
        wave = findViewById(R.id.wave)
        btnRec = findViewById(R.id.btnRec)
        btnSave = findViewById(R.id.btnSave)
        btnFile = findViewById(R.id.btnFile)
        btnBattery = findViewById(R.id.btnBattery)
        summary = findViewById(R.id.summary)
        scrim = findViewById(R.id.scrim)
        sheet = findViewById(R.id.sheet)
        sheetList = findViewById(R.id.sheetList)
        handle = findViewById(R.id.handle)
        handleRing = findViewById(R.id.handleRing)
        handleOrbit = findViewById(R.id.handleOrbit)
        handleGlow = findViewById(R.id.handleGlow)
        introHint = findViewById(R.id.introHint)
        nextHint = findViewById(R.id.nextHint)

        findViewById<View>(R.id.btnSettings).setOnClickListener { showSettings() }
        btnBattery.setOnClickListener { openBatterySettings() }

        buildWave()
        setupHandle()
        idleGroup.setOnClickListener { openSheet() }
        scrim.setOnClickListener { closeSheet() }
        orbFrame.setOnClickListener { buzz(it); onOrbTap() }
        btnRec.setOnClickListener { buzz(it); onRecTap() }
        btnSave.setOnClickListener { buzz(it); saveCurrent() }
        btnFile.setOnClickListener {
            buzz(it)
            if (state == UiState.DOCK && !recording) pickDockAudio.launch(arrayOf("audio/*"))
        }

        // ঘুরা বাটনের রিং ঘুরতে থাকবে
        ringSpin = ObjectAnimator.ofFloat(handleRing, "rotation", 0f, 360f).apply {
            duration = 3000
            interpolator = LinearInterpolator()
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        setupHandleLook()
        setupBgGlow()

        VoicePlayer.onFinished = { runOnUiThread { setPlaying(null) } }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when (state) {
                    UiState.SHEET -> closeSheet()
                    UiState.DOCK -> cancelDock()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        state = if (savedEvents().isEmpty()) UiState.IDLE else UiState.HANDLE
        handle.translationX = dp(150)
        rebuildList(true)
        showMode()
        if (state == UiState.IDLE) showIntro()

        // অভিভাবকের অ্যাপে চার্জার-ভয়েস সম্পাদনার পুরো স্ক্রিন না দেখিয়ে শুধু ছবি ও লোকেশন সংক্রান্ত সহজ প্যানেল দেখানো হয়
        // (showMode()-এর পরে, নইলে showMode() আবার stage/idleGroup দেখিয়ে দেবে)
        if (BuildConfig.IS_PARENT) {
            stage.visibility = View.GONE
            listPane.visibility = View.GONE
            dockGroup.visibility = View.GONE
            idleGroup.visibility = View.GONE
            findViewById<View>(R.id.summary).visibility = View.GONE
            findViewById<View>(R.id.parentPanel).visibility = View.VISIBLE
            findViewById<Button>(R.id.parentLiveBtn).setOnClickListener {
                buzz(it)
                if (!RemotePush.canSend(this)) {
                    toast("পেয়ারিং কোড, টোকেন আর সার্ভিস অ্যাকাউন্ট ফাইল লাগবে, গিয়ার আইকনে গিয়ে সেট করুন")
                    return@setOnClickListener
                }
                toast("লাইভ অনুরোধ পাঠানো হচ্ছে… সন্তানের ফোনে পর্যবেক্ষণ চালু না থাকলে কিছু আসবে না")
                Thread({
                    RemotePush.sendBlocking(this, org.json.JSONObject().put("k", "live").put("ts", System.currentTimeMillis()))
                }, "vp-live-req").start()
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startEngine()
        }
    }

    override fun onResume() {
        super.onResume()
        val ok = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        btnBattery.text =
            if (ok) "ব্যাটারি অপ্টিমাইজেশন বন্ধ আছে" else getString(R.string.battery_opt)
    }

    override fun onStop() {
        if (recording) stopRecording()
        stopTmp()
        super.onStop()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        VoicePlayer.onFinished = null
        VoicePlayer.stop()
        stopTmp()
        ringSpin?.cancel()
        bob?.cancel()
        introNudge?.cancel()
        stopIdleAnim()
        orbPulse?.cancel(); orbBreath?.cancel()
        waveAnims.forEach { it.cancel() }
        super.onDestroy()
    }

    private fun startEngine() {
        ContextCompat.startForegroundService(this, Intent(this, PowerService::class.java))
        // ব্লুটুথ ডিভাইস কানেক্ট ধরার জন্য Android 12+ এ এই অনুমতি লাগে
        if (Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
            != PackageManager.PERMISSION_GRANTED
        ) {
            btPermission.launch(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            askBatteryOnce()
        }
    }

    /** প্রথমবার খুললে একবারই সিস্টেমের ব্যাটারি-অপ্টিমাইজেশন ডায়ালগ দেখাবে, যাতে পরে আর অ্যাপ খুলতে না হয় */
    private fun askBatteryOnce() {
        val prefs = getSharedPreferences("voicepower", MODE_PRIVATE)
        if (prefs.getBoolean("asked_battery", false)) return
        if (getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)) return
        prefs.edit().putBoolean("asked_battery", true).apply()
        openBatterySettings()
    }

    private fun buzz(v: View) {
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun iconFor(e: PowerEvent) = when (e) {
        PowerEvent.CONNECTED -> R.drawable.ic_ev_bolt
        PowerEvent.DISCONNECTED -> R.drawable.ic_ev_plug
        PowerEvent.LEVEL_80 -> R.drawable.ic_ev_batt80
        PowerEvent.FULL -> R.drawable.ic_ev_batt100
        PowerEvent.LOW -> R.drawable.ic_ev_batt20
        PowerEvent.BT_CONNECTED -> R.drawable.ic_ev_watch
        PowerEvent.LOW10 -> R.drawable.ic_ev_batt10
        PowerEvent.LOW5 -> R.drawable.ic_ev_alert
        PowerEvent.HOT -> R.drawable.ic_ev_hot
        PowerEvent.HEADSET -> R.drawable.ic_ev_headset
    }

    // ---------- স্ক্রিনের অবস্থা ----------

    private fun showMode() {
        val saved = savedEvents()
        val dock = state == UiState.DOCK
        val hasSaved = saved.isNotEmpty()
        stage.visibility = if (dock || !hasSaved) View.VISIBLE else View.GONE
        dockGroup.visibility = if (dock) View.VISIBLE else View.GONE
        idleGroup.visibility = if (!dock && !hasSaved) View.VISIBLE else View.GONE
        if (idleGroup.visibility == View.VISIBLE) startIdleAnim() else stopIdleAnim()
        if (dock && !recording) startDockIdleAnim() else if (!dock) stopDockIdleAnim()
        listPane.visibility = if (!dock && hasSaved) View.VISIBLE else View.GONE
        btnBattery.visibility = if (dock) View.GONE else View.VISIBLE
        summary.text = "ভয়েস সেট: " + bn(saved.size) + "/" + bn(PowerEvent.values().size)
        listHeader.text =
            if (saved.size == PowerEvent.values().size) "সব ইভেন্টের ভয়েস সেট হয়েছে" else "সেভ করা ভয়েস"

        val allSaved = saved.size == PowerEvent.values().size
        bob?.cancel()
        bob = null
        if (state == UiState.SHEET) return
        if (dock || allSaved) {
            handle.animate().cancel()
            handle.visibility = View.GONE
            hideIntro()
        } else {
            handle.animate().cancel()
            handle.visibility = View.VISIBLE
            handle.alpha = 1f
            val peek = state == UiState.IDLE
            if (!peek) hideIntro()
            handle.animate().translationX(if (peek) dp(52) else 0f).setDuration(450)
                .withEndAction { if (state == UiState.IDLE) startBob() }.start()
        }
    }

    private fun startBob() {
        bob?.cancel()
        bob = ObjectAnimator.ofFloat(handle, "translationX", dp(52), dp(36)).apply {
            duration = 900
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    // ---------- ঘুরা বাটন ও শুরুর ইশারা ----------

    private fun setupHandle() {
        handle.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f
            var startTx = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        startTx = v.translationX
                        moved = false
                        v.animate().cancel()
                        bob?.cancel()
                        hideIntro()
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        if (abs(dx) > dp(8)) moved = true
                        v.translationX = (startTx + dx).coerceIn(0f, dp(150))
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val dx = downX - e.rawX
                        if (!moved || dx > dp(30)) {
                            v.performClick()
                            openSheet()
                        } else settleHandle()
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        settleHandle()
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun settleHandle() {
        handle.animate().translationX(if (state == UiState.IDLE) dp(52) else 0f).setDuration(250)
            .withEndAction { if (state == UiState.IDLE) startBob() }.start()
    }

    private fun showIntro() {
        introHint.visibility = View.VISIBLE
        introHint.animate().alpha(1f).setDuration(500).setStartDelay(600).start()
        introNudge?.cancel()
        introNudge = ObjectAnimator.ofFloat(introHint, "translationX", 0f, -dp(8)).apply {
            duration = 800
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        ui.removeCallbacks(hideIntroRun)
        ui.postDelayed(hideIntroRun, 5500)
    }

    private fun hideIntro() {
        ui.removeCallbacks(hideIntroRun)
        introNudge?.cancel()
        introNudge = null
        if (introHint.visibility != View.VISIBLE) return
        introHint.animate().cancel()
        introHint.animate().alpha(0f).setStartDelay(0).setDuration(250)
            .withEndAction { introHint.visibility = View.GONE }.start()
    }

    private fun showNext() {
        ui.removeCallbacks(hideNextRun)
        ui.postDelayed(hideNextRun, 3800)
    }

    // ---------- ইভেন্ট তালিকা (নিচ থেকে উঠে আসে) ----------

    private fun makePill(e: PowerEvent): TextView {
        val tv = TextView(this)
        tv.text = e.title
        tv.setTextColor(color(R.color.gold_light))
        tv.textSize = 16f
        tv.gravity = Gravity.CENTER_VERTICAL
        tv.setBackgroundResource(R.drawable.bg_pill)
        tv.setPadding(dpi(20), 0, dpi(20), 0)
        tv.compoundDrawablePadding = dpi(12)
        tv.setCompoundDrawablesRelativeWithIntrinsicBounds(iconFor(e), 0, 0, 0)
        tv.setCompoundDrawableTintList(ColorStateList.valueOf(color(R.color.gold)))
        return tv
    }

    private fun openSheet() {
        if (state != UiState.IDLE && state != UiState.HANDLE) return
        val pending = PowerEvent.values().filter { !VoiceStore.hasVoice(this, it) }
        if (pending.isEmpty()) return
        state = UiState.SHEET
        hideIntro()
        hideNextNow()
        bob?.cancel()
        handle.animate().cancel()
        handle.animate().alpha(0f).setDuration(200).withEndAction { handle.visibility = View.INVISIBLE }.start()

        sheetList.removeAllViews()
        val title = TextView(this)
        title.text = "কোন ইভেন্টের ভয়েস দেবেন?"
        title.setTextColor(color(R.color.text))
        title.textSize = 18f
        title.setPadding(dpi(4), 0, 0, dpi(14))
        sheetList.addView(title)
        for (e in pending) {
            val pill = makePill(e)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(52))
            lp.bottomMargin = dpi(10)
            pill.setOnClickListener { buzz(it); pickEvent(e) }
            sheetList.addView(pill, lp)
        }

        val maxH = (resources.displayMetrics.heightPixels * 0.7f).toInt()
        sheetList.measure(
            View.MeasureSpec.makeMeasureSpec(resources.displayMetrics.widthPixels, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val lp = sheet.layoutParams
        lp.height = minOf(sheetList.measuredHeight, maxH)
        sheet.layoutParams = lp
        sheet.scrollTo(0, 0)

        scrim.visibility = View.VISIBLE
        scrim.animate().alpha(1f).setDuration(250).start()
        sheet.visibility = View.VISIBLE
        sheet.translationY = resources.displayMetrics.heightPixels.toFloat()
        sheet.animate().translationY(0f).setDuration(500).start()
    }

    private fun hideSheetViews() {
        scrim.animate().alpha(0f).setDuration(250).withEndAction { scrim.visibility = View.GONE }.start()
        sheet.animate().translationY(sheet.height.toFloat() + dp(40)).setDuration(300)
            .withEndAction { sheet.visibility = View.GONE }.start()
    }

    private fun closeSheet() {
        if (state != UiState.SHEET) return
        hideSheetViews()
        state = if (savedEvents().isEmpty()) UiState.IDLE else UiState.HANDLE
        showMode()
    }

    private fun hideNextNow() {
        ui.removeCallbacks(hideNextRun)
        nextHint.animate().cancel()
        nextHint.alpha = 0f
        nextHint.visibility = View.GONE
    }

    // ---------- ইভেন্ট বাছার পর রেকর্ড স্ক্রিন ----------

    private fun pickEvent(e: PowerEvent) {
        if (state != UiState.SHEET) return
        hideSheetViews()
        VoicePlayer.stop()
        stopTmp()
        VoiceStore.tempFile(this, e).delete()
        current = e
        haveTmp = false
        recording = false
        state = UiState.DOCK

        eventPill.text = e.title
        eventPill.setCompoundDrawablesRelativeWithIntrinsicBounds(iconFor(e), 0, 0, 0)
        eventPill.setCompoundDrawableTintList(ColorStateList.valueOf(color(R.color.gold)))
        dockHint.visibility = View.GONE
        setStatus("", false)
        orbCore.setBackgroundResource(R.drawable.bg_orb_idle)
        orbRing.setBackgroundResource(R.drawable.bg_orb_ring_idle)
        orbRing2.setBackgroundResource(R.drawable.bg_orb_ring_idle)
        wave.visibility = View.INVISIBLE
        updateRecButton()
        updateSaveButton()
        showMode()
        dockGroup.alpha = 0f
        dockGroup.scaleX = 0.85f
        dockGroup.scaleY = 0.85f
        dockGroup.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(450).start()
    }

    private fun cancelDock() {
        if (recording) {
            recording = false
            ui.removeCallbacks(tick)
            try { recorder?.stop() } catch (_: Exception) {}
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null
            stopRecAnim()
        }
        stopTmp()
        current?.let { VoiceStore.tempFile(this, it).delete() }
        haveTmp = false
        current = null
        state = if (savedEvents().isEmpty()) UiState.IDLE else UiState.HANDLE
        showMode()
    }

    private fun updateRecButton() {
        val label: String
        val icon: Int
        when {
            recording -> { label = "থামান"; icon = R.drawable.ic_btn_stop }
            tmpPlayer != null -> { label = "থামান"; icon = R.drawable.ic_btn_pause }
            haveTmp -> { label = "প্লে"; icon = R.drawable.ic_btn_play }
            else -> { label = "রেকর্ড"; icon = R.drawable.ic_btn_mic }
        }
        btnRec.text = label
        btnRec.setIconResource(icon)
        btnRec.backgroundTintList = ColorStateList.valueOf(color(if (recording) R.color.red else R.color.gold))
        val fg = color(R.color.on_gold)
        btnRec.setTextColor(fg)
        btnRec.iconTint = ColorStateList.valueOf(fg)
    }

    private fun updateSaveButton() {
        val on = haveTmp && !recording
        btnSave.visibility = if (on) View.VISIBLE else View.GONE
        btnFile.isEnabled = !recording
        btnFile.alpha = if (recording) 0.4f else 1f
    }

    private fun onOrbTap() {
        if (state != UiState.DOCK) return
        val e = current ?: return
        if (recording) stopRecording() else beginRecord(e)
    }

    private fun onRecTap() {
        if (state != UiState.DOCK) return
        val e = current ?: return
        when {
            recording -> stopRecording()
            haveTmp -> toggleTmpPlay()
            else -> beginRecord(e)
        }
    }

    // ---------- রেকর্ডিং ----------

    private fun beginRecord(e: PowerEvent) {
        tmpSource = "rec"
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startRecording(e)
        } else {
            pendingRecord = e
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    @Suppress("DEPRECATION")
    private fun startRecording(e: PowerEvent) {
        VoicePlayer.stop()
        stopTmp()
        val tmp = VoiceStore.tempFile(this, e)
        try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100)
            r.setAudioEncodingBitRate(96000)
            r.setOutputFile(tmp.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            recording = true
            haveTmp = false
            secs = 0
            setStatus("রেকর্ডিং চলছে…  " + fmt(0), false)
            ui.removeCallbacks(tick)
            ui.postDelayed(tick, 1000)
            startRecAnim()
        } catch (ex: Exception) {
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null
            recording = false
            tmp.delete()
            toast("রেকর্ড শুরু করা যায়নি")
        }
        updateRecButton()
        updateSaveButton()
    }

    private fun stopRecording() {
        val e = current
        val r = recorder
        recorder = null
        recording = false
        ui.removeCallbacks(tick)
        stopRecAnim()
        if (e == null) {
            try { r?.release() } catch (_: Exception) {}
            return
        }
        val tmp = VoiceStore.tempFile(this, e)
        try {
            r?.stop()
            r?.release()
            haveTmp = tmp.exists() && tmp.length() > 0
            if (haveTmp) setStatus("", true)
            else setStatus("", false)
        } catch (ex: RuntimeException) {
            // খুব ছোট রেকর্ডিং হলে stop() ব্যর্থ হয়
            try { r?.release() } catch (_: Exception) {}
            tmp.delete()
            haveTmp = false
            setStatus("", false)
            toast("রেকর্ডিং খুব ছোট ছিল, আবার চেষ্টা করুন")
        }
        updateRecButton()
        updateSaveButton()
    }

    private fun buildWave() {
        for (i in 0 until 8) {
            val bar = View(this)
            bar.setBackgroundResource(R.drawable.bg_wave_bar)
            val lp = LinearLayout.LayoutParams(dpi(6), dpi(36))
            lp.marginStart = dpi(3)
            lp.marginEnd = dpi(3)
            wave.addView(bar, lp)
            waveBars.add(bar)
        }
    }

    // HTML-এর "ring" এনিমেশন: ১ থেকে ১.৪ গুণ বড় হয়ে মিলিয়ে যায়
    private fun ringAnim(v: View, ms: Long, delay: Long): ObjectAnimator =
        ObjectAnimator.ofPropertyValuesHolder(
            v,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.4f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.4f),
            PropertyValuesHolder.ofFloat("alpha", 0.7f, 0f)
        ).apply {
            duration = ms
            startDelay = delay
            interpolator = DecelerateInterpolator()
            repeatMode = ValueAnimator.RESTART
            repeatCount = ValueAnimator.INFINITE
            start()
        }

    private fun resetRing(v: View) { v.scaleX = 1f; v.scaleY = 1f; v.alpha = 0f }

    // রেকর্ড স্ক্রিনে রেকর্ড শুরুর আগে: দুইটা রিং পর পর ছড়িয়ে মিলিয়ে যায়
    private fun startDockIdleAnim() {
        if (recording || orbPulse?.isRunning == true) return
        orbPulse = ringAnim(orbRing, 2800, 0)
        orbPulse2 = ringAnim(orbRing2, 2800, 1400)
    }

    private fun stopDockIdleAnim() {
        orbPulse?.cancel(); orbPulse = null
        orbPulse2?.cancel(); orbPulse2 = null
        orbBreath?.cancel(); orbBreath = null
        if (::orbRing.isInitialized) resetRing(orbRing)
        if (::orbRing2.isInitialized) resetRing(orbRing2)
        if (::orbFrame.isInitialized) { orbFrame.scaleX = 1f; orbFrame.scaleY = 1f }
    }

    private fun startRecAnim() {
        stopDockIdleAnim()
        orbCore.setBackgroundResource(R.drawable.bg_orb_rec)
        orbRing.setBackgroundResource(R.drawable.bg_orb_ring_rec)
        orbRing2.setBackgroundResource(R.drawable.bg_orb_ring_rec)
        orbPulse?.cancel()
        orbPulse = ringAnim(orbRing, 1400, 0)
        orbPulse2?.cancel()
        orbPulse2 = ringAnim(orbRing2, 1400, 1400)
        // HTML-এর "beat": পুরো অর্ব ১.০৬ গুণ ধুকপুক করে
        orbBreath?.cancel()
        orbBreath = ObjectAnimator.ofPropertyValuesHolder(
            orbFrame,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.06f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.06f)
        ).apply {
            duration = 500
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        wave.visibility = View.VISIBLE
        waveAnims.forEach { it.cancel() }
        waveAnims.clear()
        for ((i, bar) in waveBars.withIndex()) {
            val a = ObjectAnimator.ofFloat(bar, "scaleY", 0.25f, 1f)
            a.duration = 450L
            a.startDelay = i * 70L
            a.repeatMode = ValueAnimator.REVERSE
            a.repeatCount = ValueAnimator.INFINITE
            a.start()
            waveAnims.add(a)
        }
    }

    // শুরুর স্ক্রিনেও একই দুই রিং (idleBreath = প্রথম রিং, idleGlow = দ্বিতীয় রিং)
    private fun startIdleAnim() {
        if (idleBreath?.isRunning == true) return
        idleBreath = ringAnim(idleRing, 2800, 0)
        idleGlow = ringAnim(idleRing2, 2800, 1400)
    }

    private fun stopIdleAnim() {
        idleBreath?.cancel(); idleBreath = null
        idleGlow?.cancel(); idleGlow = null
        if (::idleCore.isInitialized) { idleCore.scaleX = 1f; idleCore.scaleY = 1f }
        if (::idleRing.isInitialized) resetRing(idleRing)
        if (::idleRing2.isInitialized) resetRing(idleRing2)
    }

    // ঘুরা বাটন: ঘুরন্ত গ্রেডিয়েন্ট রিং, উল্টো ঘুরন্ত বিন্দু, জ্বলে-নেভা গ্লো
    private fun setupHandleLook() {
        handleRing.post {
            val c = handleRing.width / 2f
            val sweep = android.graphics.SweepGradient(
                c, c,
                intArrayOf(0xFFBFFFD8.toInt(), 0x00BFFFD8, 0xFF3FE3B8.toInt(), 0x00BFFFD8, 0xFFBFFFD8.toInt()),
                floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f)
            )
            val d = android.graphics.drawable.ShapeDrawable(android.graphics.drawable.shapes.OvalShape())
            d.paint.shader = sweep
            handleRing.background = d
        }
        handleOrbitAnim = ObjectAnimator.ofFloat(handleOrbit, "rotation", 0f, -360f).apply {
            duration = 5000
            interpolator = LinearInterpolator()
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        handleGlowAnim = ObjectAnimator.ofPropertyValuesHolder(
            handleGlow,
            PropertyValuesHolder.ofFloat("alpha", 0.55f, 1f),
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.12f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.12f)
        ).apply {
            duration = 1000
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    // পেছনের ভাসমান সবুজ আভা (HTML-এর ".bg i" এবং "drift")
    private fun setupBgGlow() {
        val host = findViewById<View>(R.id.bgGlow)
        host.post {
            val wDp = host.width / resources.displayMetrics.density
            val hDp = host.height / resources.displayMetrics.density
            // id, বৃত্তের মাপ, বাঁ-x, উপর-y (dp), শুরুর ধাপ (ms)
            val specs = listOf(
                arrayOf(R.id.bgBlob1, 300f, -80f, -140f, 0f),
                arrayOf(R.id.bgBlob2, 260f, wDp + 110f - 260f, hDp * 0.38f, 4000f),
                arrayOf(R.id.bgBlob3, 300f, -60f, hDp + 90f - 300f, 8000f),
                arrayOf(R.id.bgBlob4, 200f, wDp * 0.30f, hDp - hDp * 0.22f - 200f, 2000f)
            )
            blobAnims.forEach { it.cancel() }
            blobAnims.clear()
            for (sp in specs) {
                val v = findViewById<View>((sp[0] as Number).toInt())
                val x = ((sp[2] as Number).toFloat() - 40f) * resources.displayMetrics.density
                val y = ((sp[3] as Number).toFloat() - 40f) * resources.displayMetrics.density
                v.translationX = x
                v.translationY = y
                val a = ObjectAnimator.ofPropertyValuesHolder(
                    v,
                    PropertyValuesHolder.ofFloat("translationX", x, x + dp(40)),
                    PropertyValuesHolder.ofFloat("translationY", y, y - dp(30)),
                    PropertyValuesHolder.ofFloat("scaleX", 1f, 1.15f),
                    PropertyValuesHolder.ofFloat("scaleY", 1f, 1.15f)
                ).apply {
                    duration = 14000
                    repeatMode = ValueAnimator.REVERSE
                    repeatCount = ValueAnimator.INFINITE
                    start()
                    currentPlayTime = (sp[4] as Number).toLong()
                }
                blobAnims.add(a)
            }
        }
    }

    private fun stopRecAnim() {
        orbPulse?.cancel(); orbPulse = null
        orbPulse2?.cancel(); orbPulse2 = null
        orbBreath?.cancel(); orbBreath = null
        resetRing(orbRing)
        resetRing(orbRing2)
        orbFrame.scaleX = 1f
        orbFrame.scaleY = 1f
        waveAnims.forEach { it.cancel() }
        waveAnims.clear()
        for (b in waveBars) b.scaleY = 1f
        wave.visibility = View.INVISIBLE
        orbCore.setBackgroundResource(R.drawable.bg_orb_idle)
        orbRing.setBackgroundResource(R.drawable.bg_orb_ring_idle)
        orbRing2.setBackgroundResource(R.drawable.bg_orb_ring_idle)
        if (state == UiState.DOCK && !recording) startDockIdleAnim()
    }

    // ---------- রেকর্ড করা ভয়েস সেভের আগে শোনা ----------

    private fun toggleTmpPlay() {
        if (tmpPlayer != null) {
            stopTmp()
            return
        }
        val e = current ?: return
        val f = VoiceStore.tempFile(this, e)
        if (!f.exists() || f.length() == 0L) {
            toast("আগে ভয়েস রেকর্ড করুন")
            return
        }
        VoicePlayer.stop()
        val p = MediaPlayer()
        try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            p.setDataSource(f.absolutePath)
            p.setOnCompletionListener { stopTmp() }
            p.prepare()
            p.start()
            tmpPlayer = p
        } catch (ex: Exception) {
            try { p.release() } catch (_: Exception) {}
            tmpPlayer = null
            toast("প্লে করা যায়নি")
        }
        updateRecButton()
    }

    private fun stopTmp() {
        val p = tmpPlayer
        tmpPlayer = null
        if (p != null) {
            try { p.stop() } catch (_: Exception) {}
            try { p.release() } catch (_: Exception) {}
        }
        if (this::btnRec.isInitialized) updateRecButton()
    }

    // ---------- সেভ ----------

    private fun saveCurrent() {
        val e = current ?: return
        if (recording || !haveTmp) return
        stopTmp()
        val tmp = VoiceStore.tempFile(this, e)
        if (VoiceStore.install(this, e, tmp)) {
            VoiceStore.setSource(this, e, tmpSource)
            tmpSource = "rec"
            haveTmp = false
            current = null
            state = UiState.HANDLE
            toast("ভয়েস সেভ হয়েছে")
            rebuildList(false, e)
            showMode()
            if (savedEvents().size < PowerEvent.values().size) showNext()
        } else {
            toast("ভয়েস সেভ করা যায়নি")
        }
    }

    // ---------- সেভ করা ভয়েসের তালিকা ----------

    private fun durationSec(e: PowerEvent): Int = try {
        val r = MediaMetadataRetriever()
        r.setDataSource(VoiceStore.file(this, e).absolutePath)
        val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        r.release()
        ((ms + 500) / 1000).toInt()
    } catch (_: Exception) {
        0
    }

    private fun rebuildList(stagger: Boolean, popEvent: PowerEvent? = null) {
        rowsBox.removeAllViews()
        rowViews.clear()
        var k = 0
        for (e in savedEvents()) {
            val row = layoutInflater.inflate(R.layout.item_event, rowsBox, false)
            rowViews[e] = row
            rowsBox.addView(row)
            bindRow(e, row)
            if (stagger) {
                row.alpha = 0f
                row.translationY = 28f
                row.animate().alpha(1f).translationY(0f).setStartDelay(k * 70L).setDuration(380).start()
            } else if (e == popEvent) {
                row.alpha = 0f
                row.scaleX = 0.95f
                row.scaleY = 0.95f
                row.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(600).start()
            }
            k++
        }
        setPlaying(playingRow)
    }

    private fun bindRow(e: PowerEvent, row: View) {
        row.findViewById<TextView>(R.id.title).text = e.title
        val src = VoiceStore.source(this, e)
        val kind = if (src.isBlank() || src == "rec") "রেকর্ড করা ভয়েস" else "ফাইল: $src"
        row.findViewById<TextView>(R.id.hint).text = fmt(durationSec(e)) + " • " + kind
        row.findViewById<android.widget.ImageView>(R.id.icon).setImageResource(iconFor(e))

        val enabled = VoiceStore.isEnabled(this, e)
        row.alpha = if (enabled) 1f else 0.55f
        row.findViewById<MaterialSwitch>(R.id.enabled).apply {
            isChecked = enabled
            setOnCheckedChangeListener { _, checked ->
                VoiceStore.setEnabled(this@MainActivity, e, checked)
                row.animate().alpha(if (checked) 1f else 0.55f).setDuration(200).start()
                toast(if (checked) "ইভেন্ট চালু" else "ইভেন্ট বন্ধ")
            }
        }

        row.findViewById<Button>(R.id.btnPlay).setOnClickListener {
            buzz(it)
            if (playingRow == e) {
                VoicePlayer.stop()
                setPlaying(null)
            } else if (VoicePlayer.play(this, e)) {
                setPlaying(e)
            } else {
                toast("এই ইভেন্টের জন্য আগে ভয়েস দিন")
            }
        }
        row.findViewById<Button>(R.id.btnPick).setOnClickListener {
            buzz(it)
            pendingPick = e
            pickAudio.launch(arrayOf("audio/*"))
        }
        row.findViewById<Button>(R.id.btnDelete).setOnClickListener {
            buzz(it)
            VoicePlayer.stop()
            setPlaying(null)
            VoiceStore.clear(this, e)
            VoiceStore.setSource(this, e, "")
            toast("ভয়েস মুছে গেছে")
            rebuildList(false)
            if (state == UiState.IDLE || state == UiState.HANDLE) {
                state = if (savedEvents().isEmpty()) UiState.IDLE else UiState.HANDLE
            }
            showMode()
        }
    }

    private fun setPlaying(e: PowerEvent?) {
        playingRow = e
        for ((ev, row) in rowViews) {
            val b = row.findViewById<MaterialButton>(R.id.btnPlay)
            val on = ev == e
            b.text = if (on) "থামান" else "শুনুন"
            b.setIconResource(if (on) R.drawable.ic_btn_pause else R.drawable.ic_btn_play)
        }
    }

    // ---------- ফাইল থেকে (সেভ করা সারির "আপলোড") ----------

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (_: Exception) {
        }
        return "অডিও ফাইল"
    }

    private fun importFile(e: PowerEvent, uri: Uri) {
        val tmp = VoiceStore.tempFile(this, e)
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { out -> input.copyTo(out) }
            } ?: throw IllegalStateException("open failed")
            if (VoiceStore.install(this, e, tmp)) {
                VoiceStore.setSource(this, e, displayName(uri))
                toast("নতুন ফাইল বসেছে — এখন শুনুন")
                rebuildList(false)
                showMode()
                if (VoicePlayer.play(this, e)) setPlaying(e)
            } else {
                toast("ফাইল সেভ করা যায়নি")
            }
        } catch (ex: Exception) {
            tmp.delete()
            toast("ফাইলটি পড়া যায়নি")
        }
    }

    // ---------- সেটিংস: ভলিউম ও টেস্ট ----------

    private fun playSample() {
        val e = PowerEvent.values().firstOrNull { VoiceStore.hasVoice(this, it) }
        if (e == null) {
            toast("আগে কোনো একটা ইভেন্টে ভয়েস রেকর্ড করুন")
            return
        }
        VoicePlayer.play(this, e)
    }

    private fun showSettings() {
        val am = getSystemService(AudioManager::class.java)
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cText = ContextCompat.getColor(this, R.color.text)
        val cSub = ContextCompat.getColor(this, R.color.sub)
        val cMint = ContextCompat.getColor(this, R.color.gold_light)
        val cGreen = ContextCompat.getColor(this, R.color.primary)

        // ---------- ছোট ছোট UI helper ----------
        fun card(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_set_card)
            setPadding(dpi(14), dpi(14), dpi(14), dpi(14))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dpi(12) }
        }
        fun header(icon: Int, title: String, sub: String? = null, right: View? = null): LinearLayout {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val ic = ImageView(this)
            ic.setImageResource(icon)
            ic.setColorFilter(cMint)
            ic.setPadding(dpi(9), dpi(9), dpi(9), dpi(9))
            ic.setBackgroundResource(R.drawable.bg_set_icon)
            row.addView(ic, LinearLayout.LayoutParams(dpi(38), dpi(38)))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(TextView(this).apply {
                text = title; textSize = 16f; setTextColor(cText)
                typeface = Typeface.DEFAULT_BOLD
            })
            if (sub != null) col.addView(TextView(this).apply {
                text = sub; textSize = 12.5f; setTextColor(cSub)
            })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dpi(12) })
            if (right != null) row.addView(right)
            return row
        }
        fun btn(text: String, icon: Int? = null, onClick: () -> Unit): LinearLayout {
            val b = LinearLayout(this)
            b.orientation = LinearLayout.HORIZONTAL
            b.gravity = Gravity.CENTER
            b.setBackgroundResource(R.drawable.bg_set_btn)
            b.isClickable = true
            if (icon != null) {
                val iv = ImageView(this)
                iv.setImageResource(icon)
                iv.setColorFilter(cMint)
                b.addView(iv, LinearLayout.LayoutParams(dpi(18), dpi(18)).apply { marginEnd = dpi(8) })
            }
            b.addView(TextView(this).apply {
                this.text = text; textSize = 15f; setTextColor(cMint)
                typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            })
            b.setPadding(dpi(12), dpi(10), dpi(12), dpi(10))
            b.setOnClickListener { onClick() }
            b.minimumHeight = dpi(52)
            b.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(10) }
            return b
        }
        fun small(t: String) = TextView(this).apply {
            textSize = 12.5f; setTextColor(cSub); text = t
            setLineSpacing(0f, 1.2f)
            setPadding(dpi(4), dpi(10), dpi(4), 0)
        }
        fun styleEdit(e: EditText) {
            e.setSingleLine(true)
            e.setTextColor(cMint)
            e.setHintTextColor(cSub)
            e.background = null
            e.setPadding(0, dpi(4), 0, dpi(4))
        }
        fun field(label: String, e: EditText): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_set_code)
            setPadding(dpi(14), dpi(8), dpi(14), dpi(6))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(10) }
            addView(TextView(context).apply { text = label; textSize = 11.5f; setTextColor(cGreen) })
            addView(e, LinearLayout.LayoutParams(-1, -2))
        }

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dpi(14), dpi(22), dpi(14), dpi(6))

        // শিরোনাম
        box.addView(TextView(this).apply {
            text = "সেটিংস"; textSize = 26f; setTextColor(cMint)
            typeface = Typeface.DEFAULT_BOLD; setPadding(dpi(10), 0, 0, 0)
        })
        box.addView(TextView(this).apply {
            text = "ভলিউম ও দূর থেকে নোটিফিকেশন"; textSize = 13f; setTextColor(cSub)
            setPadding(dpi(10), dpi(4), 0, dpi(16))
        })

        // ---------- ভলিউম কার্ড ----------
        val pill = TextView(this).apply {
            textSize = 14f; setTextColor(cMint); typeface = Typeface.DEFAULT_BOLD
            setBackgroundResource(R.drawable.bg_set_pill)
            setPadding(dpi(12), dpi(4), dpi(12), dpi(4))
        }
        val seek = SeekBar(this)
        seek.max = maxVol
        seek.progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        seek.progressDrawable = ContextCompat.getDrawable(this, R.drawable.set_seek_progress)
        seek.thumb = ContextCompat.getDrawable(this, R.drawable.set_seek_thumb)
        seek.splitTrack = false
        seek.setPadding(dpi(14), 0, dpi(14), 0)

        fun updateLabel() { pill.text = bnStr("${seek.progress * 100 / maxVol}%") }
        updateLabel()

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
                    updateLabel()
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { playSample() }
        })

        val volCard = card()
        volCard.addView(header(R.drawable.ic_set_volume, "ভয়েসের ভলিউম", null, pill))
        volCard.addView(seek, LinearLayout.LayoutParams(-1, dpi(28)).apply { topMargin = dpi(10) })
        volCard.addView(small("স্লাইডার ছেড়ে দিলে ভয়েস বাজবে। এটা ফোনের মিডিয়া ভলিউম।"))
        volCard.addView(btn("টেস্ট করুন", R.drawable.ic_btn_play) { playSample() })
        box.addView(volCard)

        // ---------- ফোন পেয়ারিং কার্ড ----------
        val codeEdit = EditText(this)
        styleEdit(codeEdit)
        codeEdit.typeface = Typeface.MONOSPACE
        codeEdit.textSize = 15f
        codeEdit.letterSpacing = 0.05f
        codeEdit.setText(RemotePush.code(this).ifBlank { RemotePush.randomCode() }.let {
            if (it.contains("-")) it else it.chunked(5).joinToString("-")
        })

        val pairCard = card()
        pairCard.addView(header(R.drawable.ic_set_link, "ফোন পেয়ারিং", "দূর থেকে নোটিফিকেশন — দুই ফোনে একই কোড"))
        pairCard.addView(field("পেয়ারিং কোড", codeEdit))
        pairCard.addView(btn("নতুন কোড বানান", R.drawable.ic_set_refresh) {
            codeEdit.setText(RemotePush.randomCode())
            toast("নতুন কোড বসেছে। ঠিক আছে চাপলে চালু হবে।")
        })
        pairCard.addView(small("নতুন কোড বানালে পুরোনো ফোন কেটে যাবে").apply { gravity = Gravity.CENTER; setPadding(dpi(4), dpi(8), dpi(4), 0) })
        box.addView(pairCard)

        // ---------- ঘড়ির কাছের ফোন (গ্রহণকারী) ----------
        val recvSwitch = MaterialSwitch(this)
        recvSwitch.text = "এই ফোনে বার্তা গ্রহণ করুন"
        recvSwitch.setTextColor(cText)
        recvSwitch.isChecked = RemotePush.receiveEnabled(this)

        val tokenView = TextView(this)
        tokenView.textSize = 11.5f
        tokenView.typeface = Typeface.MONOSPACE
        tokenView.setTextIsSelectable(true)
        tokenView.setTextColor(cSub)
        tokenView.setLineSpacing(0f, 1.2f)
        tokenView.setBackgroundResource(R.drawable.bg_set_tok)
        tokenView.setPadding(dpi(14), dpi(10), dpi(8), dpi(10))
        tokenView.text = RemotePush.myToken(this)

        // ---------- পাঠানোর ফোন ----------
        val targetEdit = EditText(this)
        styleEdit(targetEdit)
        targetEdit.textSize = 15f
        targetEdit.hint = "ঘড়ির কাছের ফোনের টোকেন পেস্ট করুন"
        targetEdit.setText(RemotePush.targetToken(this))

        val saStatus = TextView(this).apply {
            textSize = 12.5f; setTextColor(cSub)
            setBackgroundResource(R.drawable.bg_set_sa)
            setPadding(dpi(12), dpi(6), dpi(12), dpi(6))
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { topMargin = dpi(10) }
        }
        fun refreshSa() {
            val pid = RemotePush.projectId(this)
            saStatus.text = if (pid.isBlank()) "○  সার্ভিস অ্যাকাউন্ট ফাইল: নেই" else "✓  সার্ভিস অ্যাকাউন্ট ফাইল: ($pid)"
            saStatus.setTextColor(if (pid.isBlank()) cSub else cGreen)
        }
        refreshSa()
        onServiceAccountPicked = { refreshSa() }

        val recvCard = card()
        recvCard.addView(header(R.drawable.ic_bell, "ঘড়ির কাছের ফোন", "গ্রহণকারী"))
        recvCard.addView(recvSwitch, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(12) })
        recvCard.addView(btn("পপআপ সবসময় দেখানোর অনুমতি") {
            if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
                toast("অনুমতি দেওয়াই আছে")
            } else {
                try {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                            .setData(Uri.parse("package:$packageName"))
                    )
                } catch (ex: Exception) { toast("সেটিংস খোলা যায়নি") }
            }
        })
        recvCard.addView(btn("পপআপ টেস্ট (এই ফোনে)", R.drawable.ic_btn_play) {
            startActivity(
                RemoteAlertActivity.intent(this, "ব্যাটারি ২০% এ নামলে", "চার্জের ফোনের ব্যাটারি কমে গেছে", PowerEvent.LOW.key)
            )
        })
        recvCard.addView(btn("এই ফোনের পরিচয় (টোকেন) দেখান") {
            try {
                FirebaseMessaging.getInstance().token.addOnSuccessListener { t ->
                    RemotePush.setMyToken(this, t)
                    tokenView.text = t
                    toast("চেপে ধরে কপি করুন")
                }.addOnFailureListener { toast("টোকেন পাওয়া যায়নি, ইন্টারনেট দেখুন") }
            } catch (ex: Exception) {
                toast("Firebase সেটআপ নেই (google-services.json)")
            }
        })
        recvCard.addView(tokenView, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(10) })
        box.addView(recvCard)

        val sendCard = card()
        sendCard.addView(header(R.drawable.ic_btn_upload, "চার্জের ফোন", "প্রেরক"))
        sendCard.addView(field("ঘড়ির কাছের ফোনের টোকেন", targetEdit))
        sendCard.addView(btn("সার্ভিস অ্যাকাউন্ট ফাইল বসান", R.drawable.ic_btn_folder) {
            pickServiceAccount.launch(arrayOf("application/json", "text/plain", "*/*"))
        })
        sendCard.addView(saStatus)
        sendCard.addView(btn("টেস্ট বার্তা পাঠান") {
            val raw = codeEdit.text.toString()
            if (!RemotePush.isValid(raw)) {
                toast("কোড কমপক্ষে ১৬ অক্ষরের হতে হবে")
                return@btn
            }
            RemotePush.setCode(this, raw)
            RemotePush.setTargetToken(this, targetEdit.text.toString())
            if (!RemotePush.canSend(this)) {
                toast("টোকেন আর সার্ভিস অ্যাকাউন্ট ফাইল দুটোই লাগবে")
                return@btn
            }
            RemotePush.send(this, "ভয়েস পাওয়ার টেস্ট", "এই বার্তা এলে সব ঠিক আছে")
            toast("পাঠানো হয়েছে")
        })
        box.addView(sendCard)

        // ---------- জরুরি সাহায্য ----------
        val emgSwitch = MaterialSwitch(this)
        emgSwitch.text = "ভলিউম বাটন দুইবার চাপলে জরুরি বার্তা"
        emgSwitch.setTextColor(cText)
        emgSwitch.isChecked = Emergency.enabled(this) && Emergency.hasPermissions(this)
        emgSwitch.setOnCheckedChangeListener { btnView, on ->
            if (on) {
                if (Emergency.hasPermissions(this)) {
                    Emergency.setEnabled(this, true)
                    refreshService()
                } else {
                    onEmgPermResult = { ok ->
                        if (ok) {
                            Emergency.setEnabled(this, true)
                            refreshService()
                        } else {
                            btnView.isChecked = false
                            toast("মাইক আর লোকেশনের অনুমতি দুটোই লাগবে")
                        }
                    }
                    val perms = mutableListOf(
                        Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                    emgPermission.launch(perms.toTypedArray())
                }
            } else {
                Emergency.setEnabled(this, false)
                refreshService()
            }
        }

        val emgCard = card()
        emgCard.addView(header(R.drawable.ic_ev_alert, "জরুরি সাহায্য", "চার্জের ফোন"))
        emgCard.addView(small("চালু থাকলে ভলিউম বাটন দুইবার দ্রুত চাপলে: সঙ্গে সঙ্গে লোকেশন যাবে, তারপর ২ মিনিটের মাইক রেকর্ড আপলোড হয়ে ঘড়ির কাছের ফোনে পপআপ আসবে। এর জন্য ওপরের পেয়ারিং সেটআপ (কোড, টোকেন, সার্ভিস অ্যাকাউন্ট ফাইল) আগে করে নিন। চালু থাকলে ভলিউম বাটন দিয়ে ফোনের ভলিউম বদলানো যাবে না।"))
        emgCard.addView(emgSwitch, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(12) })
        emgCard.addView(btn("জরুরি টেস্ট (১০ সেকেন্ড রেকর্ড)") {
            if (!Emergency.hasPermissions(this)) {
                toast("আগে সুইচ চালু করে অনুমতি দিন")
                return@btn
            }
            val raw = codeEdit.text.toString()
            if (RemotePush.isValid(raw)) RemotePush.setCode(this, raw)
            RemotePush.setTargetToken(this, targetEdit.text.toString())
            if (!RemotePush.canSend(this)) {
                toast("পেয়ারিং কোড, টোকেন আর সার্ভিস অ্যাকাউন্ট ফাইল লাগবে")
                return@btn
            }
            try {
                ContextCompat.startForegroundService(
                    this, Intent(this, PowerService::class.java).setAction(PowerService.ACTION_EMERGENCY_TEST)
                )
                toast("টেস্ট শুরু হয়েছে, ঘড়ির কাছের ফোনে বার্তা যাবে")
            } catch (ex: Exception) { toast("শুরু করা যায়নি, অ্যাপ খোলা রেখে আবার চেষ্টা করুন") }
        })
        box.addView(emgCard)

        // ---------- শিশু স্ক্রিন নিয়ন্ত্রণ ----------
        val intervals = listOf("১ ঘণ্টা" to 3_600_000L, "২ ঘণ্টা" to 7_200_000L, "৩ ঘণ্টা" to 10_800_000L, "৬ ঘণ্টা" to 21_600_000L, "১২ ঘণ্টা" to 43_200_000L)
        val curInterval = ScreenWatchService.intervalMs(this)
        val intervalGroup = android.widget.RadioGroup(this).apply {
            orientation = android.widget.RadioGroup.VERTICAL
            intervals.forEachIndexed { i, (label, ms) ->
                addView(android.widget.RadioButton(this@MainActivity).apply {
                    id = i + 900
                    text = label
                    setTextColor(cText)
                    buttonTintList = ColorStateList.valueOf(cGreen)
                    isChecked = ms == curInterval
                    setOnCheckedChangeListener { _, on -> if (on) ScreenWatchService.setIntervalMs(this@MainActivity, ms) }
                })
            }
        }
        val swStatus = TextView(this).apply {
            text = if (ScreenWatchService.running) "✅ পর্যবেক্ষণ চলছে" else "⏸ বন্ধ আছে"
            textSize = 14f; setTextColor(cText)
            setPadding(dpi(4), dpi(12), 0, 0)
        }

        val childCard = card()
        childCard.addView(header(R.drawable.ic_ev_watch, "শিশু স্ক্রিন নিয়ন্ত্রণ"))
        childCard.addView(small("ফিচারটি শুধু আপনার সন্তানের ফোনে চালাবেন। চালু করলে নির্দিষ্ট সময় পর পর ফোনের স্ক্রিনশট তুলে আপনার ফোনে পাঠাবে। প্রতিটি স্ক্রিনশটের জন্য অ্যান্ড্রয়েডের নিজস্ব অনুমতি ডায়ালগ আসবে।"))
        if (!BuildConfig.IS_PARENT) {
        childCard.addView(small("ছবি পাঠানোর সময়সীমা:"))
        childCard.addView(intervalGroup)
        childCard.addView(swStatus)
        childCard.addView(btn("চালু কর (অনুমতি লাগবে)") {
            if (!RemotePush.canSend(this)) {
                toast("পেয়ারিং কোড, টোকেন ও সার্ভিস অ্যাকাউন্ট ফাইল আগে সেট করুন"); return@btn
            }
            startActivity(Intent(this, ScreenWatchLaunchActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            android.os.Handler(mainLooper).postDelayed({ swStatus.text = if (ScreenWatchService.running) "✅ পর্যবেক্ষণ চলছে" else "⏸ বন্ধ আছে" }, 3000)
        })
        childCard.addView(btn("বন্ধ কর") {
            ContextCompat.startForegroundService(this, Intent(this, ScreenWatchService::class.java).setAction(ScreenWatchService.ACTION_STOP))
            android.os.Handler(mainLooper).postDelayed({ swStatus.text = "⏸ বন্ধ আছে" }, 1000)
        })
        }
        if (BuildConfig.IS_PARENT) {
            childCard.addView(btn("লাইভ দেখুন (৫ মিনিট, ৩ সেকেন্ড পরপর)") {
                if (!RemotePush.canSend(this)) {
                    toast("পেয়ারিং কোড, টোকেন আর সার্ভিস অ্যাকাউন্ট ফাইল লাগবে")
                    return@btn
                }
                toast("লাইভ অনুরোধ পাঠানো হচ্ছে… সন্তানের ফোনে পর্যবেক্ষণ চালু না থাকলে কিছু আসবে না")
                Thread({
                    RemotePush.sendBlocking(this, org.json.JSONObject().put("k", "live").put("ts", System.currentTimeMillis()))
                }, "vp-live-req").start()
            })
        }
        box.addView(childCard)

        // ---------- ডায়ালগ: ওপরে গোল কোণার শিট, নিচে স্থির বাতিল/ঠিক আছে বার ----------
        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(box)

        val dialog = android.app.Dialog(this)
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL or Gravity.END
        bar.setPadding(dpi(18), dpi(10), dpi(18), dpi(20))
        bar.addView(TextView(this).apply {
            text = "বাতিল"; textSize = 15f; setTextColor(cSub)
            setPadding(dpi(16), dpi(12), dpi(16), dpi(12))
            setOnClickListener { dialog.dismiss() }
        })
        bar.addView(TextView(this).apply {
            text = "ঠিক আছে"; textSize = 15f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.on_gold))
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_set_ok)
            isClickable = true
            setOnClickListener {
                val raw = codeEdit.text.toString()
                if (RemotePush.isValid(raw)) RemotePush.setCode(this@MainActivity, raw)
                else if (normalizeBlank(raw)) RemotePush.setCode(this@MainActivity, "")
                else toast("কোড ছোট, সেভ হয়নি")
                RemotePush.setReceive(this@MainActivity, recvSwitch.isChecked)
                RemotePush.setTargetToken(this@MainActivity, targetEdit.text.toString())
                dialog.dismiss()
            }
        }, LinearLayout.LayoutParams(dpi(130), dpi(52)).apply { marginStart = dpi(8) })

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundResource(R.drawable.bg_set_sheet)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))

        dialog.setContentView(root)
        dialog.window?.apply {
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
            val appH = this@MainActivity.findViewById<View>(android.R.id.content).height.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels
            setLayout(-1, (appH * 0.92f).toInt())
            setGravity(Gravity.BOTTOM)
            setDimAmount(0.6f)
            if (Build.VERSION.SDK_INT >= 31) {
                addFlags(android.view.WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                val lp = attributes
                lp.blurBehindRadius = dpi(8)
                attributes = lp
            }
        }
        root.alpha = 0f
        dialog.show()
        root.post {
            root.translationY = root.height.toFloat()
            root.alpha = 1f
            root.animate().translationY(0f).setDuration(500)
                .setInterpolator(android.view.animation.PathInterpolator(0.2f, 0.9f, 0.25f, 1f)).start()
        }
    }

    // ---------- ব্যাটারি অপ্টিমাইজেশন ----------

    private fun openBatterySettings() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("ইতিমধ্যে বন্ধ করা আছে")
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (ex: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun normalizeBlank(raw: String) = RemotePush.normalize(raw).isEmpty()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
