package com.voicepower

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.NotificationManager
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** অন্য ফোন থেকে বার্তা এলে অ্যাপের নিজের রঙে এই পপআপ আসে */
class RemoteAlertActivity : AppCompatActivity() {

    private var pulse: ObjectAnimator? = null
    private var listenPlayer: MediaPlayer? = null
    private var audioUrl = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setFinishOnTouchOutside(false)
        setContentView(R.layout.activity_remote_alert)

        // ব্যাক বাটন চাপলেও ভয়েস থামবে আর নোটিফিকেশন সরবে
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { dismiss() }
        })
        findViewById<View>(R.id.popOk).setOnClickListener { dismiss() }
        findViewById<View>(R.id.popOpen).setOnClickListener {
            dismiss()
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        findViewById<View>(R.id.popMap).setOnClickListener {
            val maps = intent.getStringExtra(EXTRA_MAPS) ?: ""
            if (maps.isNotBlank()) try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(maps)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
        }
        findViewById<TextView>(R.id.popListen).setOnClickListener { toggleListen() }
        bind(intent)

        val card = findViewById<View>(R.id.card)
        card.alpha = 0f
        card.scaleX = 0.88f
        card.scaleY = 0.88f
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(320).start()

        pulse = ObjectAnimator.ofPropertyValuesHolder(
            findViewById<View>(R.id.popRing),
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.08f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.08f),
            PropertyValuesHolder.ofFloat("alpha", 1f, 0.4f)
        ).apply {
            duration = 900
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        bind(intent)
    }

    private fun bind(i: Intent) {
        val key = i.getStringExtra(EXTRA_KEY) ?: ""
        val ev = PowerEvent.values().firstOrNull { it.key == key }
        findViewById<ImageView>(R.id.popIcon).setImageResource(iconRes(ev))
        findViewById<TextView>(R.id.popTitle).text = i.getStringExtra(EXTRA_TITLE) ?: "ভয়েস পাওয়ার"
        val msg = i.getStringExtra(EXTRA_MSG) ?: ""
        findViewById<TextView>(R.id.popMsg).apply {
            text = msg
            visibility = if (msg.isBlank()) View.GONE else View.VISIBLE
        }
        // জরুরি বার্তা: লাল ট্যাগ, ম্যাপ আর রেকর্ডের বাটন
        val emg = key == Emergency.KEY
        val maps = i.getStringExtra(EXTRA_MAPS) ?: ""
        val audio = i.getStringExtra(EXTRA_AUDIO) ?: ""
        findViewById<TextView>(R.id.popTag).apply {
            text = if (emg) "জরুরি সাহায্য" else "দূর থেকে আসা বার্তা"
            setTextColor(androidx.core.content.ContextCompat.getColor(this@RemoteAlertActivity, if (emg) R.color.red else R.color.amber))
        }
        if (emg) findViewById<ImageView>(R.id.popIcon).setImageResource(R.drawable.ic_ev_alert)

        // স্ক্রিন পর্যবেক্ষণের ছবি: সরাসরি পপআপে দেখাবে, লাইভ মোডে নতুন ছবি এলে বদলে যাবে
        val shot = findViewById<ImageView>(R.id.popShot)
        val imgUrl = i.getStringExtra(EXTRA_AUDIO) ?: ""
        if (key == "sw" && imgUrl.isNotBlank()) {
            shot.visibility = View.VISIBLE
            loadShot(imgUrl, shot)
        } else {
            shot.visibility = View.GONE
        }

        findViewById<View>(R.id.popExtraRow).visibility = if (emg && (maps.isNotBlank() || audio.isNotBlank())) View.VISIBLE else View.GONE
        findViewById<View>(R.id.popMap).visibility = if (maps.isNotBlank()) View.VISIBLE else View.GONE
        findViewById<View>(R.id.popListen).visibility = if (audio.isNotBlank()) View.VISIBLE else View.GONE
        if (audio.isNotBlank() && audio != audioUrl) { stopListen(); audioUrl = audio }
        val at = i.getLongExtra(EXTRA_TIME, System.currentTimeMillis())
        findViewById<TextView>(R.id.popTime).text =
            SimpleDateFormat("hh:mm a", Locale("bn")).format(Date(at))
    }

    /** রেকর্ড সরাসরি ইন্টারনেট থেকে চালায় (ডাউনলোড করে রাখে না) */
    private fun toggleListen() {
        val btn = findViewById<TextView>(R.id.popListen)
        if (listenPlayer != null) { stopListen(); return }
        if (audioUrl.isBlank()) return
        btn.text = "লোড হচ্ছে…"
        val p = MediaPlayer()
        listenPlayer = p
        try {
            p.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            p.setDataSource(audioUrl)
            p.setOnPreparedListener { mp -> mp.start(); btn.text = "থামান" }
            p.setOnCompletionListener { stopListen() }
            p.setOnErrorListener { _, _, _ -> stopListen(); btn.text = "আবার চেষ্টা করুন"; true }
            p.prepareAsync()
        } catch (_: Exception) {
            stopListen()
            btn.text = "আবার চেষ্টা করুন"
        }
    }

    private fun stopListen() {
        listenPlayer?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
        listenPlayer = null
        findViewById<TextView>(R.id.popListen)?.text = "রেকর্ড শুনুন"
    }

    private fun loadShot(url: String, into: ImageView) {
        Thread({
            try {
                val bmp = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).run {
                    connectTimeout = 10000; readTimeout = 10000
                    inputStream.use { android.graphics.BitmapFactory.decodeStream(it) }
                }
                if (bmp != null) runOnUiThread { if (!isFinishing) into.setImageBitmap(bmp) }
            } catch (_: Exception) {}
        }, "vp-shot").start()
    }

    private fun dismiss() {
        stopListen()
        VoicePlayer.stop()
        try { getSystemService(NotificationManager::class.java).cancel(popupNotifId(intent.getStringExtra(EXTRA_KEY))) } catch (_: Exception) {}
        finish()
    }

    override fun onDestroy() {
        listenPlayer?.let { try { it.release() } catch (_: Exception) {} }
        listenPlayer = null
        pulse?.cancel()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_TITLE = "pop_title"
        const val EXTRA_MSG = "pop_msg"
        const val EXTRA_KEY = "pop_key"
        const val EXTRA_TIME = "pop_time"
        const val EXTRA_MAPS = "pop_maps"
        const val EXTRA_AUDIO = "pop_audio"

        fun popupNotifId(key: String?): Int =
            500 + (PowerEvent.values().firstOrNull { it.key == key }?.ordinal ?: 99)

        fun iconRes(e: PowerEvent?): Int = when (e) {
            PowerEvent.CONNECTED -> R.drawable.ic_ev_bolt
            PowerEvent.DISCONNECTED -> R.drawable.ic_ev_plug
            PowerEvent.LEVEL_80 -> R.drawable.ic_ev_batt80
            PowerEvent.FULL -> R.drawable.ic_ev_batt100
            PowerEvent.LOW -> R.drawable.ic_ev_batt20
            PowerEvent.BT_CONNECTED -> R.drawable.ic_ev_watch
            PowerEvent.LOW10 -> R.drawable.ic_ev_batt10
            PowerEvent.LOW5 -> R.drawable.ic_ev_alert
            PowerEvent.HOT -> R.drawable.ic_ev_hot
            PowerEvent.HEADSET -> R.drawable.ic_ev_headset
            null -> R.drawable.ic_bell
        }

        fun intent(ctx: android.content.Context, title: String, msg: String, key: String, maps: String = "", audio: String = "") =
            Intent(ctx, RemoteAlertActivity::class.java)
                .putExtra(EXTRA_TITLE, title)
                .putExtra(EXTRA_MSG, msg)
                .putExtra(EXTRA_KEY, key)
                .putExtra(EXTRA_MAPS, maps)
                .putExtra(EXTRA_AUDIO, audio)
                .putExtra(EXTRA_TIME, System.currentTimeMillis())
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
    }
}
