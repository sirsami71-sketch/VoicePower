package com.voicepower

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat

/**
 * স্বচ্ছ অ্যাক্টিভিটি — অ্যান্ড্রয়েডের MediaProjection অনুমতি ডায়ালগ দেখায়।
 * অনুমতি পেলে ScreenWatchService চালু করে, না পেলে বন্ধ হয়।
 */
class ScreenWatchLaunchActivity : Activity() {
    companion object { private const val REQ = 700 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ইতিমধ্যে চললে আবার চালু করতে হবে না
        if (ScreenWatchService.running) {
            Toast.makeText(this, "পর্যবেক্ষণ ইতিমধ্যে চলছে", Toast.LENGTH_SHORT).show()
            finish(); return
        }
        val mgr = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK && data != null) {
            val svc = Intent(this, ScreenWatchService::class.java)
                .putExtra(ScreenWatchService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(ScreenWatchService.EXTRA_DATA, data)
            try {
                ContextCompat.startForegroundService(this, svc)
                Toast.makeText(this, "স্ক্রিন পর্যবেক্ষণ শুরু হয়েছে", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "শুরু করা যায়নি: ${e.message}", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "অনুমতি দেওয়া হয়নি, পর্যবেক্ষণ বন্ধ", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
