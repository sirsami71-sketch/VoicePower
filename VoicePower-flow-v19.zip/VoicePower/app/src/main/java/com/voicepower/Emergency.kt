package com.voicepower

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.HandlerThread
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.firebase.FirebaseApp
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URLEncoder
import java.util.UUID

/**
 * জরুরি সিস্টেম (প্রেরক ফোন):
 *  ভলিউম বাটন দুইবার চাপ → সঙ্গে সঙ্গে লোকেশনসহ বার্তা → ২ মিনিট মাইক রেকর্ড → আপলোড → রেকর্ডের লিংক পাঠানো
 * সব বার্তা পেয়ারিং কোড দিয়ে এনক্রিপ্টেড (RemotePush)।
 */
object Emergency {
    const val KEY = "emergency"
    const val REC_SECONDS = 120
    const val TEST_SECONDS = 10
    const val NOTIF_ID = 400
    const val CH = "emergency_v1"
    private const val PREFS = "voicepower"
    private const val KEY_ON = "emergency_on"
    private const val SCOPE_STORAGE = "https://www.googleapis.com/auth/devstorage.read_write"

    @Volatile
    private var running = false

    fun isRunning() = running

    fun enabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ON, false)

    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ON, on).apply()
    }

    private fun granted(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    fun hasPermissions(ctx: Context): Boolean =
        granted(ctx, Manifest.permission.RECORD_AUDIO) &&
            (granted(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ||
                granted(ctx, Manifest.permission.ACCESS_COARSE_LOCATION))

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "জরুরি সাহায্য", NotificationManager.IMPORTANCE_HIGH).apply {
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 500)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setSound(
                    android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM),
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                )
            }
        )
    }

    /** ভলিউম ডাবল-প্রেস বা টেস্ট বাটন থেকে ডাকা হয়। আগের জরুরি কাজ চলতে থাকলে আবার শুরু হয় না */
    @Synchronized
    fun start(ctx: Context, test: Boolean = false) {
        if (running) return
        val app = ctx.applicationContext
        if (!RemotePush.canSend(app)) {
            progress(app, "জরুরি বার্তা পাঠানো যায়নি", "পেয়ারিং কোড, টোকেন আর সার্ভিস অ্যাকাউন্ট ফাইল সেটিংসে বসান", done = true)
            return
        }
        running = true
        buzz(app)
        Thread({ run(app, test) }, "vp-emergency").start()
    }

    @Suppress("DEPRECATION")
    private fun buzz(ctx: Context) {
        try {
            val v = ctx.getSystemService(Vibrator::class.java) ?: return
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE))
            else v.vibrate(400)
        } catch (_: Exception) {}
    }

    private fun progress(ctx: Context, title: String, text: String, done: Boolean) {
        ensureChannel(ctx)
        val b = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setOngoing(!done)
            .setAutoCancel(done)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, b.build())
    }

    private fun run(ctx: Context, test: Boolean) {
        val pm = ctx.getSystemService(PowerManager::class.java)
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voicepower:emergency")
        wl.acquire(5 * 60 * 1000L)
        var file: File? = null
        try {
            val prefix = if (test) "[টেস্ট] " else ""
            progress(ctx, "জরুরি বার্তা পাঠানো হচ্ছে", "লোকেশন খোঁজা হচ্ছে…", done = false)

            // ১) লোকেশন + সঙ্গে সঙ্গে প্রথম বার্তা
            val loc = EmergencyLocation.get(ctx, 20_000)
            val first = JSONObject().put("t", prefix + "🚨 জরুরি সাহায্য দরকার").put("k", KEY)
            if (loc != null) {
                val maps = "https://www.google.com/maps/search/?api=1&query=${loc.latitude},${loc.longitude}"
                first.put("m", "আমার লোকেশন পাঠানো হয়েছে (সঠিকতা প্রায় ${loc.accuracy.toInt()} মিটার)। ২ মিনিটের রেকর্ড আসছে…")
                    .put("maps", maps)
            } else {
                first.put("m", "লোকেশন পাওয়া যায়নি। ২ মিনিটের রেকর্ড আসছে…")
            }
            val sent = sendWithRetry(ctx, first)
            progress(ctx, "২ মিনিট রেকর্ড চলছে", if (sent) "লোকেশন পাঠানো হয়েছে" else "লোকেশন পাঠানো যায়নি, নেট দেখুন", done = false)

            // ২) রেকর্ড
            file = record(ctx, if (test) TEST_SECONDS else REC_SECONDS)

            // ৩) আপলোড + লিংক পাঠানো
            var url: String? = null
            if (file != null) {
                progress(ctx, "রেকর্ড আপলোড হচ্ছে", "অপেক্ষা করুন…", done = false)
                repeat(3) { i -> if (url == null) { url = upload(ctx, file!!); if (url == null) Thread.sleep(4000L * (i + 1)) } }
            }
            val second = JSONObject().put("t", prefix + "🚨 জরুরি রেকর্ড এসেছে").put("k", KEY)
            if (loc != null) second.put("maps", "https://www.google.com/maps/search/?api=1&query=${loc.latitude},${loc.longitude}")
            if (url != null) {
                second.put("m", "রেকর্ড শুনতে নিচের বাটন চাপুন").put("a", url)
            } else {
                second.put("m", "রেকর্ড আপলোড করা যায়নি" + if (file == null) " (মাইক চালু হয়নি)" else "")
            }
            val ok2 = sendWithRetry(ctx, second)
            progress(
                ctx, "জরুরি বার্তা শেষ",
                if (url != null && ok2) "লোকেশন ও রেকর্ড দুটোই পাঠানো হয়েছে" else "কিছু অংশ পাঠানো যায়নি",
                done = true
            )
        } catch (e: Exception) {
            progress(ctx, "জরুরি বার্তায় সমস্যা", e.message ?: "অজানা সমস্যা", done = true)
        } finally {
            try { file?.delete() } catch (_: Exception) {}
            if (wl.isHeld) wl.release()
            running = false
        }
    }

    private fun sendWithRetry(ctx: Context, payload: JSONObject, tries: Int = 4): Boolean {
        repeat(tries) { i ->
            payload.put("ts", System.currentTimeMillis())
            if (RemotePush.sendBlocking(ctx, payload)) return true
            try { Thread.sleep(3000L * (i + 1)) } catch (_: InterruptedException) { return false }
        }
        return false
    }

    private fun record(ctx: Context, seconds: Int): File? {
        val f = File(ctx.cacheDir, "emg_${System.currentTimeMillis()}.m4a")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
        return try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(16000)
            r.setAudioEncodingBitRate(32000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            val end = SystemClock.elapsedRealtime() + seconds * 1000L
            while (SystemClock.elapsedRealtime() < end) Thread.sleep(500)
            r.stop()
            if (f.exists() && f.length() > 0) f else null
        } catch (e: Exception) {
            try { r.stop() } catch (_: Exception) {}
            if (f.exists() && f.length() > 1024) f else null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    /**
     * সার্ভিস অ্যাকাউন্ট দিয়ে Firebase Storage বাকেটে আপলোড (নিয়ম/Rules বদলাতে হয় না)।
     * ফাইলে ডাউনলোড-টোকেন বসানো হয়, তাই লিংকটা অনুমান-অযোগ্য; লিংক আবার এনক্রিপ্টেড বার্তায় যায়।
     */
    private fun upload(ctx: Context, file: File): String? = try {
        val sa = JSONObject(RemotePush.serviceAccount(ctx))
        val bucket = FirebaseApp.getInstance().options.storageBucket
        if (bucket.isNullOrBlank()) null
        else {
            val token = FcmSender.accessToken(sa, SCOPE_STORAGE)
            if (token == null) null
            else {
                val name = "emergency/${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.m4a"
                val dl = UUID.randomUUID().toString()
                val boundary = "vp" + UUID.randomUUID().toString().replace("-", "")
                val meta = JSONObject()
                    .put("name", name)
                    .put("contentType", "audio/mp4")
                    .put("metadata", JSONObject().put("firebaseStorageDownloadTokens", dl))
                val out = ByteArrayOutputStream()
                out.write("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n".toByteArray())
                out.write("--$boundary\r\nContent-Type: audio/mp4\r\n\r\n".toByteArray())
                out.write(file.readBytes())
                out.write("\r\n--$boundary--\r\n".toByteArray())
                val (code, _) = FcmSender.postBytes(
                    "https://storage.googleapis.com/upload/storage/v1/b/$bucket/o?uploadType=multipart",
                    "multipart/related; boundary=$boundary", out.toByteArray(), token, 60_000
                )
                if (code in 200..299)
                    "https://firebasestorage.googleapis.com/v0/b/$bucket/o/" +
                        URLEncoder.encode(name, "UTF-8") + "?alt=media&token=$dl"
                else null
            }
        }
    } catch (_: Exception) {
        null
    }
}

/** লোকেশন: GPS আর নেটওয়ার্ক দুটোই চেষ্টা করে সবচেয়ে ভালোটা নেয় */
object EmergencyLocation {
    @SuppressLint("MissingPermission")
    fun get(ctx: Context, timeoutMs: Long): Location? {
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return null
        val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return null

        val providers = mutableListOf<String>()
        try { if (fine && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) providers += LocationManager.GPS_PROVIDER } catch (_: Exception) {}
        try { if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) providers += LocationManager.NETWORK_PROVIDER } catch (_: Exception) {}

        var best: Location? = null
        val lock = Any()
        val listener = object : LocationListener {
            override fun onLocationChanged(l: Location) {
                synchronized(lock) { if (best == null || l.accuracy < best!!.accuracy) best = l }
            }
            @Deprecated("old API")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        val ht = HandlerThread("vp-loc").also { it.start() }
        try {
            providers.forEach { p ->
                try { lm.requestLocationUpdates(p, 0L, 0f, listener, ht.looper) } catch (_: Exception) {}
            }
            val start = SystemClock.elapsedRealtime()
            while (true) {
                Thread.sleep(500)
                val el = SystemClock.elapsedRealtime() - start
                val b = synchronized(lock) { best }
                if (b != null && (b.accuracy <= 50f || el >= 8000)) break
                if (el >= timeoutMs) break
            }
        } catch (_: Exception) {
        } finally {
            try { lm.removeUpdates(listener) } catch (_: Exception) {}
            ht.quitSafely()
        }
        val got = synchronized(lock) { best }
        if (got != null) return got
        // শেষ ভরসা: ফোনে আগে থেকে জমা থাকা সবচেয়ে নতুন লোকেশন
        return try {
            lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
        } catch (_: Exception) { null }
    }
}

/** গ্রহণকারী ফোনে জরুরি বার্তার নোটিফিকেশন + পপআপ */
object EmergencyNotifier {
    fun show(ctx: Context, d: JSONObject) {
        Emergency.ensureChannel(ctx)
        val title = d.optString("t", "🚨 জরুরি সাহায্য")
        val msg = d.optString("m", "")
        val maps = d.optString("maps", "")
        val audio = d.optString("a", "")

        val popupIntent = RemoteAlertActivity.intent(ctx, title, msg, Emergency.KEY, maps, audio)
        val popup = PendingIntent.getActivity(
            ctx, 650, popupIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(ctx, Emergency.CH)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(msg)
            .setStyle(NotificationCompat.BigTextStyle().bigText(msg))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setLocalOnly(false)
            .setContentIntent(popup)
            .setFullScreenIntent(popup, true)
        if (maps.isNotBlank()) {
            val mapPi = PendingIntent.getActivity(
                ctx, 651, Intent(Intent.ACTION_VIEW, Uri.parse(maps)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(android.R.drawable.ic_menu_mylocation, "ম্যাপে দেখুন", mapPi)
        }
        if (audio.isNotBlank()) b.addAction(android.R.drawable.ic_media_play, "রেকর্ড শুনুন", popup)

        ctx.getSystemService(NotificationManager::class.java)
            .notify(RemoteAlertActivity.popupNotifId(Emergency.KEY), b.build())

        if (RemoteNotifier.canDirect(ctx)) {
            try { ctx.startActivity(popupIntent) } catch (_: Exception) {}
        }
    }
}
