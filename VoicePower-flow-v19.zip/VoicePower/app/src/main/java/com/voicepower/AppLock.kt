package com.voicepower

import android.content.Context
import java.security.MessageDigest
import java.security.SecureRandom

// অ্যাপ খোলার পিন। পিন সরাসরি রাখা হয় না, লবণ দিয়ে হ্যাশ করে রাখা হয়
object AppLock {
    private const val PREFS = "vp_lock"
    private const val KEY_HASH = "pin_hash"
    private const val KEY_SALT = "pin_salt"

    private fun sp(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun hash(pin: String, salt: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun hasPin(ctx: Context): Boolean = sp(ctx).getString(KEY_HASH, null) != null

    fun isValid(pin: String): Boolean = pin.length in 4..6 && pin.all { it.isDigit() }

    fun setPin(ctx: Context, pin: String) {
        val salt = ByteArray(12).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        sp(ctx).edit().putString(KEY_SALT, salt).putString(KEY_HASH, hash(pin, salt)).apply()
    }

    fun check(ctx: Context, pin: String): Boolean {
        val h = sp(ctx).getString(KEY_HASH, null) ?: return true
        val salt = sp(ctx).getString(KEY_SALT, "") ?: ""
        return hash(pin, salt) == h
    }

    fun clear(ctx: Context) {
        sp(ctx).edit().remove(KEY_HASH).remove(KEY_SALT).apply()
    }
}
