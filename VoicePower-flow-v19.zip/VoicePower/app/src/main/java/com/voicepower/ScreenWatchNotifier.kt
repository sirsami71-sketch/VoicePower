package com.voicepower

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat

/** প্যারেন্টের ফোনে স্ক্রিনশট নোটিফিকেশন দেখায় */
object ScreenWatchNotifier {
    private const val NOTIF_ID = 501

    fun show(ctx: android.content.Context, d: org.json.JSONObject) {
        ScreenWatchService.ensureChannel(ctx)
        val url = d.optString("a", "")
        val msg = d.optString("m", "স্ক্রিনশট দেখুন")

        // ছবির URL খুলবে
        val openIntent = if (url.isNotBlank())
            PendingIntent.getActivity(
                ctx, 710,
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            ) else null

        // পপআপ intent — RemoteAlertActivity-তে ছবির URL দেখাবে
        val popupIntent = RemoteAlertActivity.intent(ctx, "📱 স্ক্রিনশট এসেছে", msg, "sw", "", url)
        val popupPi = PendingIntent.getActivity(
            ctx, 711, popupIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val b = NotificationCompat.Builder(ctx, ScreenWatchService.CH)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("📱 নতুন স্ক্রিনশট")
            .setContentText(msg)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(popupPi)
        if (openIntent != null) b.addAction(android.R.drawable.ic_menu_gallery, "ছবি দেখুন", openIntent)

        ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, b.build())

        if (RemoteNotifier.canDirect(ctx)) {
            try { ctx.startActivity(popupIntent) } catch (_: Exception) {}
        }
    }
}
