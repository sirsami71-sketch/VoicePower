package com.voicepower

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.URLEncoder
import java.util.UUID

/**
 * শিশু নিয়ন্ত্রণ — স্ক্রিন পর্যবেক্ষণ (প্রেরক ফোন):
 * নির্দিষ্ট সময় পর পর স্ক্রিনশট তুলে Firebase Storage-এ আপলোড করে,
 * FCM-এ ছবির লিংক পাঠায় → প্যারেন্টের ফোনে পপআপ দেখায়।
 */
class ScreenWatchService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "sw_result_code"
        const val EXTRA_DATA = "sw_proj_data"
        const val ACTION_STOP = "com.voicepower.SCREEN_WATCH_STOP"
        const val CH = "screen_watch_v1"
        const val FG_ID = 500
        private const val PREFS = "voicepower"
        private const val KEY_INTERVAL = "sw_interval_ms"
        private const val SCOPE = "https://www.googleapis.com/auth/devstorage.read_write"

        @Volatile
        var running = false

        fun intervalMs(ctx: Context): Long =
            ctx.getSharedPreferences(PREFS, MODE_PRIVATE).getLong(KEY_INTERVAL, 60_000L)

        fun setIntervalMs(ctx: Context, ms: Long) =
            ctx.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putLong(KEY_INTERVAL, ms).apply()

        fun ensureChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH, "শিশু স্ক্রিন পর্যবেক্ষণ", NotificationManager.IMPORTANCE_LOW)
                    .apply { setShowBadge(false) }
            )
        }
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var ht: HandlerThread? = null
    private var handler: Handler? = null
    private var ticker: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        ensureChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }

        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent?.getParcelableExtra(EXTRA_DATA)

        if (code == -1 || data == null) { stopSelf(); return START_NOT_STICKY }

        val notif = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= 29)
                ServiceCompat.startForeground(this, FG_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            else startForeground(FG_ID, notif)
        } catch (_: Exception) { try { startForeground(FG_ID, notif) } catch (_: Exception) {} }

        val mgr = getSystemService(MediaProjectionManager::class.java)
        projection = mgr.getMediaProjection(code, data)
        if (projection == null) { stopSelf(); return START_NOT_STICKY }

        // স্ক্রিনের সাইজ, স্কেল করে অর্ধেক → ব্যান্ডউইথ কম লাগে
        val wm = getSystemService(WindowManager::class.java)
        val (w, h, dpi) = if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Triple(b.width(), b.height(), resources.displayMetrics.densityDpi)
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getMetrics(m)
            Triple(m.widthPixels, m.heightPixels, m.densityDpi)
        }
        val capW = (w * 0.5f).toInt().coerceAtLeast(360)
        val capH = (h * 0.5f).toInt().coerceAtLeast(640)

        val thread = HandlerThread("vp-sw").also { it.start() }
        ht = thread
        val h2 = Handler(thread.looper)
        handler = h2

        imageReader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection!!.createVirtualDisplay(
            "VPWatch", capW, capH, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, h2
        )

        val interval = intervalMs(this)
        val r = object : Runnable {
            override fun run() {
                if (!running) return
                captureAndSend()
                h2.postDelayed(this, interval)
            }
        }
        ticker = r
        h2.postDelayed(r, 2000L)

        return START_NOT_STICKY
    }

    private fun captureAndSend() {
        val img = try { imageReader?.acquireLatestImage() } catch (_: Exception) { return } ?: return
        val bytes: ByteArray
        try {
            val plane = img.planes[0]
            val ps = plane.pixelStride
            val rs = plane.rowStride
            val buf = plane.buffer
            val bmp = Bitmap.createBitmap(rs / ps, img.height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(buf)
            val cropped = Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
            bmp.recycle()
            val out = ByteArrayOutputStream()
            cropped.compress(Bitmap.CompressFormat.JPEG, 55, out)
            cropped.recycle()
            bytes = out.toByteArray()
        } finally {
            try { img.close() } catch (_: Exception) {}
        }
        if (bytes.isEmpty()) return
        Thread({ uploadAndNotify(bytes) }, "vp-sw-up").start()
    }

    private fun uploadAndNotify(bytes: ByteArray) {
        if (!RemotePush.canSend(this)) return
        val sa = try { JSONObject(RemotePush.serviceAccount(this)) } catch (_: Exception) { return }
        val bucket = try { com.google.firebase.FirebaseApp.getInstance().options.storageBucket } catch (_: Exception) { null }
        if (bucket.isNullOrBlank()) return
        val token = FcmSender.accessToken(sa, SCOPE) ?: return

        val name = "screenwatch/${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg"
        val dlToken = UUID.randomUUID().toString()
        val meta = JSONObject().put("name", name).put("contentType", "image/jpeg")
            .put("metadata", JSONObject().put("firebaseStorageDownloadTokens", dlToken))
        val boundary = "vpswb" + UUID.randomUUID().toString().replace("-", "")
        val body = ByteArrayOutputStream()
        body.write("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n".toByteArray())
        body.write("--$boundary\r\nContent-Type: image/jpeg\r\n\r\n".toByteArray())
        body.write(bytes)
        body.write("\r\n--$boundary--\r\n".toByteArray())

        val (code, _) = FcmSender.postBytes(
            "https://storage.googleapis.com/upload/storage/v1/b/$bucket/o?uploadType=multipart",
            "multipart/related; boundary=$boundary", body.toByteArray(), token, 30_000
        )
        if (code !in 200..299) return

        val url = "https://firebasestorage.googleapis.com/v0/b/$bucket/o/" +
            URLEncoder.encode(name, "UTF-8") + "?alt=media&token=$dlToken"

        RemotePush.sendBlocking(
            this,
            JSONObject().put("t", "📱 স্ক্রিনশট এসেছে").put("m", "শিশুর ফোনের স্ক্রিন")
                .put("a", url).put("k", "sw").put("ts", System.currentTimeMillis())
        )
    }

    private fun buildNotification(): Notification {
        val stopPi = PendingIntent.getService(
            this, 700,
            Intent(this, ScreenWatchService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("শিশু স্ক্রিন পর্যবেক্ষণ চলছে")
            .setContentText("প্রতি ${intervalMs(this) / 1000} সেকেন্ডে স্ক্রিনশট পাঠানো হচ্ছে")
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "বন্ধ কর", stopPi)
            .build()
    }

    override fun onDestroy() {
        running = false
        ticker?.let { handler?.removeCallbacks(it) }
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        ht?.quitSafely()
        super.onDestroy()
    }
}
