package com.voicepower

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Base64
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec

/** ঘড়ির কাছের ফোনে গুগলের পুশ আসলে সিস্টেম নিজে এটা জাগায়; অ্যাপ ব্যাকগ্রাউন্ডে চালু রাখতে হয় না */
class PushService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        RemotePush.setMyToken(this, token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        if (!RemotePush.receiveEnabled(this)) return
        val enc = message.data["p"] ?: return
        // সঠিক কোডে এনক্রিপ্ট না হলে বার্তা চুপচাপ বাদ
        val d = RemotePush.decrypt(this, enc) ?: return
        RemoteNotifier.show(this, d)
    }
}

object RemoteNotifier {
    const val CH_REMOTE = "remote_v1"

    private fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_REMOTE, "দূর থেকে আসা বার্তা", NotificationManager.IMPORTANCE_HIGH).apply {
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 200, 120, 200)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(PowerService.CH_EVENTS, "চার্জ ও ব্যাটারি ইভেন্ট", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 200, 120, 200)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
    }

    /** অ্যাপ সামনে থাকলে বা "অন্য অ্যাপের ওপর দেখানো" অনুমতি থাকলে সরাসরি পপআপ খোলা যায় */
    fun canDirect(ctx: Context): Boolean =
        ctx.getSystemService(android.app.ActivityManager::class.java)
            ?.runningAppProcesses?.any {
                it.processName == ctx.packageName &&
                    it.importance <= android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE
            } == true || (Build.VERSION.SDK_INT >= 23 && android.provider.Settings.canDrawOverlays(ctx))

    fun show(ctx: Context, d: JSONObject) {
        if (d.optString("k") == Emergency.KEY) { EmergencyNotifier.show(ctx, d); return }
        if (d.optString("k") == "sw") { ScreenWatchNotifier.show(ctx, d); return }
        ensureChannels(ctx)
        val title = d.optString("t", "ভয়েস পাওয়ার")
        val msg = d.optString("m", "")
        val key = d.optString("k", "")
        val ev = PowerEvent.values().firstOrNull { it.key == key }
        // এই ফোনে ওই ইভেন্টের নিজের ভয়েস থাকলে সেটা বাজবে
        val played = ev != null && VoiceStore.isEnabled(ctx, ev) && VoicePlayer.play(ctx, ev)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        // অ্যাপের রঙের পপআপ: লক স্ক্রিন/স্ক্রিন বন্ধ থাকলে fullScreenIntent দিয়ে ওঠে
        // নোটিফিকেশন সরালে (সোয়াইপ বা বাটন) ভয়েসও থামবে
        val stop = PendingIntent.getService(
            ctx, 700 + (ev?.ordinal ?: 99),
            Intent(ctx, PowerService::class.java).setAction(PowerService.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val popupIntent = RemoteAlertActivity.intent(ctx, title, msg, key)
        val popup = PendingIntent.getActivity(
            ctx, 600 + (ev?.ordinal ?: 99), popupIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, if (played) PowerService.CH_EVENTS else CH_REMOTE)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle(title)
            .setContentText(msg)
            .setStyle(NotificationCompat.BigTextStyle().bigText(msg))
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setLocalOnly(false)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(popup)
            .setFullScreenIntent(popup, true)
            .setDeleteIntent(stop)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "বন্ধ করুন", stop)
            .addAction(android.R.drawable.ic_menu_view, "অ্যাপ খুলুন", open)
            .build()
        ctx.getSystemService(NotificationManager::class.java)
            .notify(RemoteAlertActivity.popupNotifId(key), n)
        // অ্যাপ খোলা থাকলে বা "অন্য অ্যাপের ওপর দেখানো" অনুমতি থাকলে সরাসরি পপআপ খুলে দেয়
        if (canDirect(ctx)) {
            try { ctx.startActivity(popupIntent) } catch (_: Exception) {}
        }
    }
}

/** FCM v1 দিয়ে বার্তা পাঠায়। সার্ভিস অ্যাকাউন্ট ফাইল দিয়ে নিজেই অনুমতি-টোকেন বানায় (কোনো সার্ভার লাগে না) */
object FcmSender {
    private const val FCM_SCOPE = "https://www.googleapis.com/auth/firebase.messaging"
    private val tokenCache = HashMap<String, Pair<String, Long>>()

    private fun b64url(b: ByteArray) =
        Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)

    private fun post(url: String, contentType: String, body: String, bearer: String? = null): Pair<Int, String> =
        postBytes(url, contentType, body.toByteArray(Charsets.UTF_8), bearer)

    fun postBytes(url: String, contentType: String, body: ByteArray, bearer: String? = null, timeoutMs: Int = 10000): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10000
        c.readTimeout = timeoutMs
        c.doOutput = true
        c.setFixedLengthStreamingMode(body.size)
        c.setRequestProperty("Content-Type", contentType)
        if (bearer != null) c.setRequestProperty("Authorization", "Bearer $bearer")
        c.outputStream.use { it.write(body) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        c.disconnect()
        return code to text
    }

    @Synchronized
    fun accessToken(sa: JSONObject, scope: String = FCM_SCOPE): String? {
        val now = System.currentTimeMillis()
        tokenCache[scope]?.let { (t, exp) -> if (t.isNotEmpty() && now < exp - 60_000) return t }

        val iat = now / 1000
        val claims = JSONObject()
            .put("iss", sa.getString("client_email"))
            .put("scope", scope)
            .put("aud", "https://oauth2.googleapis.com/token")
            .put("iat", iat)
            .put("exp", iat + 3600)
        val header = b64url("""{"alg":"RS256","typ":"JWT"}""".toByteArray())
        val input = header + "." + b64url(claims.toString().toByteArray())

        val pem = sa.getString("private_key")
            .replace("-----BEGIN PRIVATE KEY-----", "")
            .replace("-----END PRIVATE KEY-----", "")
            .replace("\\s".toRegex(), "")
        val key = KeyFactory.getInstance("RSA")
            .generatePrivate(PKCS8EncodedKeySpec(Base64.decode(pem, Base64.DEFAULT)))
        val sig = Signature.getInstance("SHA256withRSA").run {
            initSign(key)
            update(input.toByteArray())
            sign()
        }
        val jwt = input + "." + b64url(sig)

        val (code, text) = post(
            "https://oauth2.googleapis.com/token",
            "application/x-www-form-urlencoded",
            "grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=$jwt"
        )
        if (code != 200) return null
        val j = JSONObject(text)
        val t = j.optString("access_token", "")
        tokenCache[scope] = t to (now + j.optLong("expires_in", 3600) * 1000)
        return t.ifEmpty { null }
    }

    /** সফল হলে true */
    fun send(serviceAccountJson: String, targetToken: String, encrypted: String): Boolean = try {
        val sa = JSONObject(serviceAccountJson)
        val token = accessToken(sa)
        if (token == null) false
        else {
            val msg = JSONObject().put(
                "message", JSONObject()
                    .put("token", targetToken)
                    .put("data", JSONObject().put("p", encrypted))
                    .put("android", JSONObject().put("priority", "HIGH").put("ttl", "600s"))
            )
            val (code, _) = post(
                "https://fcm.googleapis.com/v1/projects/${sa.getString("project_id")}/messages:send",
                "application/json; charset=utf-8", msg.toString(), token
            )
            code in 200..299
        }
    } catch (_: Exception) {
        false
    }
}
