package com.voicepower

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

// অ্যাডমিন চালু থাকলে আনইনস্টলের আগে অ্যাডমিন বন্ধ করতে হয়
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "অ্যাডমিন বন্ধ করলে অ্যাপ সহজে আনইনস্টল করা যাবে"
}
