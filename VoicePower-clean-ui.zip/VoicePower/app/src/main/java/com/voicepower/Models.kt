package com.voicepower

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.PowerManager
import java.io.File
import org.json.JSONObject

enum class PowerEvent(val key: String, val title: String, val hint: String) {
    CONNECTED("connected", "চার্জার লাগালে", "চার্জার লাগানোর সাথে সাথে বাজবে"),
    DISCONNECTED("disconnected", "চার্জার খুললে", "চার্জার খোলার সাথে সাথে বাজবে"),
    LEVEL_80("level80", "ব্যাটারি ৮০% হলে", "চার্জ দেওয়ার সময় ৮০% ছুঁলে বাজবে"),
    FULL("full", "ব্যাটারি ১০০% হলে", "চার্জ দেওয়ার সময় ফুল হলে বাজবে"),
    LOW("low20", "ব্যাটারি ২০% এ নামলে", "চার্জ ছাড়া অবস্থায় ২০% বা কমে নামলে বাজবে"),
    BT_CONNECTED("btconnected", "ব্লুটুথ ডিভাইস কানেক্ট হলে", "ঘড়ি/ডিভাইস কানেক্ট হলে পপআপ আসবে, বন্ধ না করা পর্যন্ত বাজতে থাকবে"),
    LOW10("low10", "ব্যাটারি ১০% এ নামলে", "চার্জ ছাড়া অবস্থায় ১০% বা কমে নামলে বাজবে"),
    LOW5("low5", "ব্যাটারি ৫% এ নামলে", "চার্জ ছাড়া অবস্থায় ৫% বা কমে নামলে বাজবে"),
    HOT("hot", "ফোন গরম হলে", "ফোনের তাপমাত্রা ৪২°C ছাড়ালে বাজবে"),
    HEADSET("headset", "হেডফোন লাগালে", "তারের হেডফোন/ইয়ারফোন লাগালে বাজবে")
}

object VoiceStore {
    private const val PREFS = "voicepower"

    private fun dir(ctx: Context): File =
        File(ctx.filesDir, "voices").apply { mkdirs() }

    fun file(ctx: Context, e: PowerEvent): File = File(dir(ctx), "${e.key}.m4a")

    fun tempFile(ctx: Context, e: PowerEvent): File = File(dir(ctx), "${e.key}.tmp")

    fun hasVoice(ctx: Context, e: PowerEvent): Boolean =
        file(ctx, e).let { it.exists() && it.length() > 0 }

    /** পুরোনো ভয়েসের জায়গায় নতুন ভয়েস বসায় */
    fun install(ctx: Context, e: PowerEvent, tmp: File): Boolean {
        val target = file(ctx, e)
        target.delete()
        return tmp.renameTo(target)
    }

    fun clear(ctx: Context, e: PowerEvent) {
        file(ctx, e).delete()
    }

    fun isEnabled(ctx: Context, e: PowerEvent): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(e.key, true)

    fun setEnabled(ctx: Context, e: PowerEvent, enabled: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(e.key, enabled).apply()
    }
}

object VoicePlayer {
    private var player: MediaPlayer? = null

    @Synchronized
    fun play(ctx: Context, e: PowerEvent): Boolean {
        val f = VoiceStore.file(ctx.applicationContext, e)
        if (!f.exists() || f.length() == 0L) return false
        stop()
        val p = MediaPlayer()
        return try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            // স্ক্রিন বন্ধ/লক থাকলেও যেন ভয়েস শেষ পর্যন্ত বাজে
            p.setWakeMode(ctx.applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(f.absolutePath)
            p.setOnCompletionListener { mp ->
                mp.release()
                synchronized(this) { if (player === mp) player = null }
            }
            p.setOnErrorListener { mp, _, _ ->
                mp.release()
                synchronized(this) { if (player === mp) player = null }
                true
            }
            p.prepare()
            p.start()
            player = p
            true
        } catch (ex: Exception) {
            p.release()
            false
        }
    }

    @Synchronized
    fun stop() {
        player?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        player = null
    }
}

/**
 * দূর থেকে বার্তা (গুগলের FCM পুশ দিয়ে — ফোন ২-এ অ্যাপ চালিয়ে রাখতে হয় না)। সুরক্ষা:
 *  - দুই ফোনে একই গোপন "পেয়ারিং কোড" লাগে (এটাই অনুমতি)
 *  - বার্তা AES-256-GCM দিয়ে এনক্রিপ্টেড; ভুল কোডের ফোন পড়তে বা জাল বার্তা দিতে পারে না
 *  - দশ মিনিটের পুরোনো বার্তা বাতিল (রিপ্লে ঠেকাতে)
 */
object RemotePush {
    private const val PREFS = "voicepower"
    private const val KEY_CODE = "pair_code"
    private const val KEY_RECV = "ntfy_receive"
    private const val KEY_TOKEN = "fcm_my_token"
    private const val KEY_TARGET = "fcm_target_token"
    private const val KEY_SA = "fcm_service_account"
    private const val MAX_AGE_MS = 10 * 60 * 1000L

    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---- কোড ----
    fun normalize(raw: String): String = raw.lowercase().filter { it.isLetterOrDigit() }
    fun code(ctx: Context): String = p(ctx).getString(KEY_CODE, "") ?: ""
    fun setCode(ctx: Context, raw: String) { p(ctx).edit().putString(KEY_CODE, normalize(raw)).apply() }
    fun isValid(raw: String) = normalize(raw).length >= 16

    /** ২০ অক্ষরের কঠিন কোড, ৫টা করে দলে */
    fun randomCode(): String {
        val chars = "abcdefghjkmnpqrstuvwxyz23456789"
        val r = java.security.SecureRandom()
        return (1..20).map { chars[r.nextInt(chars.length)] }.joinToString("").chunked(5).joinToString("-")
    }

    // ---- গ্রহণকারী ফোন ----
    fun receiveEnabled(ctx: Context): Boolean = p(ctx).getBoolean(KEY_RECV, false)
    fun setReceive(ctx: Context, on: Boolean) { p(ctx).edit().putBoolean(KEY_RECV, on).apply() }
    fun myToken(ctx: Context): String = p(ctx).getString(KEY_TOKEN, "") ?: ""
    fun setMyToken(ctx: Context, t: String) { p(ctx).edit().putString(KEY_TOKEN, t).apply() }

    // ---- পাঠানোর ফোন ----
    fun targetToken(ctx: Context): String = p(ctx).getString(KEY_TARGET, "") ?: ""
    fun setTargetToken(ctx: Context, t: String) { p(ctx).edit().putString(KEY_TARGET, t.trim()).apply() }
    fun serviceAccount(ctx: Context): String {
        val saved = p(ctx).getString(KEY_SA, "") ?: ""
        if (saved.isNotBlank()) return saved
        // বিল্ডের সময় GitHub Secret থেকে অ্যাপের ভেতরে ঢোকানো ফাইল (থাকলে)
        return try {
            ctx.assets.open("sa.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Exception) {
            ""
        }
    }
    fun setServiceAccount(ctx: Context, json: String) { p(ctx).edit().putString(KEY_SA, json).apply() }

    fun projectId(ctx: Context): String = try {
        JSONObject(serviceAccount(ctx)).optString("project_id", "")
    } catch (_: Exception) { "" }

    fun isValidServiceAccount(json: String): Boolean = try {
        val j = JSONObject(json)
        j.has("client_email") && j.has("private_key") && j.has("project_id")
    } catch (_: Exception) { false }

    // ---- এনক্রিপশন ----
    private fun sha256(s: String): ByteArray =
        java.security.MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))

    private fun key(ctx: Context) =
        javax.crypto.spec.SecretKeySpec(sha256("key:${code(ctx)}"), "AES")

    private fun encrypt(ctx: Context, plain: String): String {
        val iv = ByteArray(12).also { java.security.SecureRandom().nextBytes(it) }
        val c = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        c.init(javax.crypto.Cipher.ENCRYPT_MODE, key(ctx), javax.crypto.spec.GCMParameterSpec(128, iv))
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return android.util.Base64.encodeToString(iv + ct, android.util.Base64.NO_WRAP)
    }

    /** ভুল কোড/জাল/বদলানো/পুরোনো বার্তা হলে null */
    fun decrypt(ctx: Context, b64: String): JSONObject? = try {
        val all = android.util.Base64.decode(b64, android.util.Base64.NO_WRAP)
        val c = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        c.init(javax.crypto.Cipher.DECRYPT_MODE, key(ctx),
            javax.crypto.spec.GCMParameterSpec(128, all.copyOfRange(0, 12)))
        val j = JSONObject(String(c.doFinal(all.copyOfRange(12, all.size)), Charsets.UTF_8))
        if (Math.abs(System.currentTimeMillis() - j.optLong("ts")) > MAX_AGE_MS) null else j
    } catch (_: Exception) {
        null
    }

    /** পাঠানোর জন্য সব ঠিকঠাক সাজানো আছে কিনা */
    fun canSend(ctx: Context) =
        code(ctx).length >= 16 && targetToken(ctx).isNotBlank() && isValidServiceAccount(serviceAccount(ctx))

    fun send(ctx: Context, title: String, text: String, urgent: Boolean = false, key: String = "general") {
        if (!canSend(ctx)) return
        val payload = JSONObject()
            .put("t", title).put("m", text.ifBlank { title }).put("k", key)
            .put("ts", System.currentTimeMillis()).toString()
        val enc = try { encrypt(ctx, payload) } catch (_: Exception) { return }
        val sa = serviceAccount(ctx)
        val target = targetToken(ctx)
        Thread { FcmSender.send(sa, target, enc) }.start()
    }
}
