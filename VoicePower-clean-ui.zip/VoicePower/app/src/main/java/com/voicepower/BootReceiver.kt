package com.voicepower

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, PowerService::class.java))
            } catch (_: Exception) {
                // সিস্টেম ব্যাকগ্রাউন্ড থেকে সার্ভিস চালুর অনুমতি না দিলে ক্র্যাশ এড়াতে; অ্যাপ খুললেই চালু হবে
            }
        }
    }
}
