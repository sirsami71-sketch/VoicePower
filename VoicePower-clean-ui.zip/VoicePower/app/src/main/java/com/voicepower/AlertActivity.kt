package com.voicepower

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

/** ব্লুটুথ ডিভাইস কানেক্ট হলে এই পপআপ আসে; "বন্ধ করুন" চাপলে ভয়েস থামে */
class AlertActivity : Activity() {

    private val closer = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setFinishOnTouchOutside(false)

        val name = intent.getStringExtra(PowerService.EXTRA_NAME) ?: "ব্লুটুথ ডিভাইস"
        val pad = (24 * resources.displayMetrics.density).toInt()

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(pad, pad, pad, pad)

        val icon = TextView(this)
        icon.text = ""
        icon.textSize = 48f
        icon.gravity = Gravity.CENTER

        val title = TextView(this)
        title.text = "ব্লুটুথ কানেক্ট হয়েছে"
        title.textSize = 20f
        title.gravity = Gravity.CENTER

        val sub = TextView(this)
        sub.text = name
        sub.textSize = 16f
        sub.gravity = Gravity.CENTER
        sub.setPadding(0, pad / 3, 0, pad)

        val stop = Button(this)
        stop.text = "বন্ধ করুন"
        stop.setOnClickListener { stopAlert() }

        box.addView(icon)
        box.addView(title)
        box.addView(sub)
        box.addView(stop)
        setContentView(box)

        ContextCompat.registerReceiver(
            this, closer, IntentFilter(PowerService.ACTION_CLOSE_ALERT),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    private fun stopAlert() {
        startService(Intent(this, PowerService::class.java).setAction(PowerService.ACTION_STOP))
        finish()
    }

    override fun onDestroy() {
        try { unregisterReceiver(closer) } catch (_: Exception) {}
        super.onDestroy()
    }
}
