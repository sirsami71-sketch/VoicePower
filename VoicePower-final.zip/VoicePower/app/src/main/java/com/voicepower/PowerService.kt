package com.voicepower

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.io.File

class PowerService : Service() {

    companion object {
        const val CH_SERVICE = "service"
        const val CH_EVENTS = "events_v3"
        const val ACTION_REPLAY = "com.voicepower.REPLAY"
        const val EXTRA_EVENT = "event_key"
        const val FG_ID = 1
        const val ACTION_STOP = "com.voicepower.STOP_ALERT"
        const val ACTION_CLOSE_ALERT = "com.voicepower.CLOSE_ALERT"
        const val EXTRA_NAME = "device_name"
        const val CH_ALERT = "bt_alert_v1"
        const val BT_ID = 300
        const val HOT_C = 42f       // এর বেশি হলে "ফোন গরম"
        const val HOT_RESET_C = 38f // এর নিচে নামলে আবার সতর্ক করবে
        const val REPEAT_COUNT = 5 // প্রতিটি ইভেন্টে ভয়েস টানা কতবার বাজবে
    }

    private var lastLevel = -1
    private var lastTemp = 0f
    private var hotFired = false
    private var alerting = false
    private val fired = mutableSetOf<PowerEvent>()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_POWER_CONNECTED -> {
                    fired.clear()
                    // আগে থেকেই ৮০%/১০০% হলে আলাদা করে আবার ঘোষণা করবে না
                    if (lastLevel >= 80) fired += PowerEvent.LEVEL_80
                    if (lastLevel >= 100) fired += PowerEvent.FULL
                    trigger(PowerEvent.CONNECTED)
                }
                Intent.ACTION_POWER_DISCONNECTED -> {
                    fired.clear()
                    trigger(PowerEvent.DISCONNECTED)
                }
                Intent.ACTION_BATTERY_CHANGED -> onBattery(intent)
                Intent.ACTION_HEADSET_PLUG -> {
                    // সার্ভিস চালুর সময় আসা পুরোনো অবস্থার ব্রডকাস্ট বাদ
                    if (!isInitialStickyBroadcast && intent.getIntExtra("state", 0) == 1)
                        trigger(PowerEvent.HEADSET)
                }
                BluetoothDevice.ACTION_ACL_CONNECTED -> onBtConnected(intent)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, FG_ID, buildForegroundNotification(), type)

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_HEADSET_PLUG)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // নোটিফিকেশনের "▶ আবার শুনুন" বাটন — অ্যাপ না খুলেই ভয়েস বাজবে
        if (intent?.action == ACTION_REPLAY) {
            val key = intent.getStringExtra(EXTRA_EVENT)
            PowerEvent.values().firstOrNull { it.key == key }?.let { RepeatPlayer.stop(); VoicePlayer.play(this, it) }
        }
        if (intent?.action == ACTION_STOP) stopAlert()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        VoicePlayer.stop()
        RepeatPlayer.stop()
        try { getSystemService(NotificationManager::class.java).cancel(BT_ID) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun onBattery(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level < 0 || scale <= 0) return
        val pct = level * 100 / scale
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val tempC = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        lastTemp = tempC

        val prev = lastLevel
        lastLevel = pct

        // ফোন গরম: ৪২°C ছাড়ালে একবার; ৩৮°C এর নিচে নামলে আবার সতর্ক করবে
        if (tempC >= HOT_C) {
            if (!hotFired) {
                hotFired = true
                if (prev != -1) trigger(PowerEvent.HOT)
            }
        } else if (tempC <= HOT_RESET_C) {
            hotFired = false
        }

        // সার্ভিস চালু হওয়ার প্রথম রিডিং: শুধু অবস্থা মনে রাখো, কিছু বাজিও না
        if (prev == -1) {
            if (plugged) {
                if (pct >= 80) fired += PowerEvent.LEVEL_80
                if (pct >= 100) fired += PowerEvent.FULL
            } else {
                if (pct <= 20) fired += PowerEvent.LOW
                if (pct <= 10) fired += PowerEvent.LOW10
                if (pct <= 5) fired += PowerEvent.LOW5
            }
            return
        }

        if (plugged) {
            if (prev < 80 && pct >= 80 && PowerEvent.LEVEL_80 !in fired) {
                fired += PowerEvent.LEVEL_80
                trigger(PowerEvent.LEVEL_80)
            }
            if (pct >= 100 && PowerEvent.FULL !in fired) {
                fired += PowerEvent.FULL
                trigger(PowerEvent.FULL)
            }
        } else {
            if (pct <= 20 && prev > 20 && PowerEvent.LOW !in fired) {
                fired += PowerEvent.LOW
                trigger(PowerEvent.LOW)
            }
            if (pct > 20) fired -= PowerEvent.LOW
            if (pct <= 10 && prev > 10 && PowerEvent.LOW10 !in fired) {
                fired += PowerEvent.LOW10
                trigger(PowerEvent.LOW10)
            }
            if (pct > 10) fired -= PowerEvent.LOW10
            if (pct <= 5 && prev > 5 && PowerEvent.LOW5 !in fired) {
                fired += PowerEvent.LOW5
                trigger(PowerEvent.LOW5)
            }
            if (pct > 5) fired -= PowerEvent.LOW5
        }
    }

    private fun trigger(e: PowerEvent) {
        if (!VoiceStore.isEnabled(this, e)) return
        if (alerting) stopAlert()
        val played = RepeatPlayer.play(this, e, REPEAT_COUNT)
        showEventNotification(e, played)
        val extra = buildString {
            if (lastLevel >= 0) append("ব্যাটারি $lastLevel%")
            if (e == PowerEvent.HOT) append(" • %.1f°C".format(lastTemp))
        }
        RemotePush.send(this, e.title, extra, urgent = e == PowerEvent.HOT || e == PowerEvent.LOW5, key = e.key)
    }

    // ---------- ব্লুটুথ কানেক্ট পপআপ ----------

    private fun onBtConnected(intent: Intent) {
        if (!VoiceStore.isEnabled(this, PowerEvent.BT_CONNECTED)) return
        if (alerting) return
        alerting = true
        val name = deviceName(intent) ?: "ব্লুটুথ ডিভাইস"
        // বন্ধ না করা পর্যন্ত বাজতেই থাকবে
        val played = RepeatPlayer.play(this, PowerEvent.BT_CONNECTED, Int.MAX_VALUE)
        showBtAlert(name, played)
        RemotePush.send(this, "ব্লুটুথ কানেক্ট হয়েছে", name, key = PowerEvent.BT_CONNECTED.key)
    }

    @Suppress("DEPRECATION")
    private fun deviceName(intent: Intent): String? {
        val d: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        } else {
            intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
        }
        return try { d?.name } catch (_: SecurityException) { null }
    }

    private fun showBtAlert(name: String, played: Boolean) {
        val open = PendingIntent.getActivity(
            this, 300,
            Intent(this, AlertActivity::class.java)
                .putExtra(EXTRA_NAME, name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 301,
            Intent(this, PowerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CH_ALERT)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("ব্লুটুথ কানেক্ট হয়েছে")
            .setContentText(name + if (played) "" else " • ভয়েস সেট করা নেই")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .setDeleteIntent(stop)
            .addAction(android.R.drawable.ic_media_pause, "⏹ বন্ধ করুন", stop)
            .build()
        getSystemService(NotificationManager::class.java).notify(BT_ID, n)
    }

    private fun stopAlert() {
        alerting = false
        RepeatPlayer.stop()
        getSystemService(NotificationManager::class.java).cancel(BT_ID)
        sendBroadcast(Intent(ACTION_CLOSE_ALERT).setPackage(packageName))
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "ব্যাকগ্রাউন্ড সার্ভিস", NotificationManager.IMPORTANCE_LOW).apply {
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
        nm.deleteNotificationChannel("events_v2")
        nm.createNotificationChannel(
            NotificationChannel(CH_EVENTS, "চার্জ ও ব্যাটারি ইভেন্ট", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null) // শব্দ বাজবে আপনার নিজের ভয়েসে
                // ছোট কম্পন: স্মার্টওয়াচ অ্যাপ সাধারণত এমন "আসল" নোটিফিকেশনই ঘড়িতে পাঠায়
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 200, 120, 200)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC // লক স্ক্রিনে পুরো দেখাবে
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "ব্লুটুথ কানেক্ট পপআপ", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
    }

    private fun openAppIntent(): PendingIntent =
        PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun buildForegroundNotification(): Notification =
        NotificationCompat.Builder(this, CH_SERVICE)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle("ভয়েস পাওয়ার চালু আছে")
            .setContentText("চার্জার ও ব্যাটারির দিকে নজর রাখছে")
            .setOngoing(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent())
            .build()

    private fun showEventNotification(e: PowerEvent, played: Boolean) {
        var battery = if (lastLevel >= 0) " • ব্যাটারি $lastLevel%" else ""
        if (e == PowerEvent.HOT) battery += " • 🌡 %.1f°C".format(lastTemp)
        val b = NotificationCompat.Builder(this, CH_EVENTS)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle(e.title)
            .setContentText((if (played) "🔊 আপনার ভয়েস বাজানো হয়েছে" else "এই ইভেন্টের জন্য কোনো ভয়েস সেট করা নেই") + battery)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setLocalOnly(false)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
        if (played) {
            val replay = PendingIntent.getService(
                this, 200 + e.ordinal,
                Intent(this, PowerService::class.java).setAction(ACTION_REPLAY).putExtra(EXTRA_EVENT, e.key),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(android.R.drawable.ic_media_play, "▶ আবার শুনুন", replay)
        }
        val n = b.build()
        getSystemService(NotificationManager::class.java).notify(100 + e.ordinal, n)
    }
}

/** একই ভয়েস টানা কয়েকবার বাজায় (শুধু এই ফাইলেই আছে, Models.kt বদলাতে হয় না) */
object RepeatPlayer {
    private var player: MediaPlayer? = null

    @Synchronized
    fun play(ctx: Context, e: PowerEvent, times: Int): Boolean {
        val app = ctx.applicationContext
        val f = VoiceStore.file(app, e)
        if (!f.exists() || f.length() == 0L) return false
        VoicePlayer.stop()
        stop()
        return startOne(app, f, times.coerceAtLeast(1))
    }

    @Synchronized
    private fun startOne(app: Context, f: File, left: Int): Boolean {
        val p = MediaPlayer()
        return try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            p.setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(f.absolutePath)
            p.setOnCompletionListener { mp ->
                mp.release()
                synchronized(this) {
                    if (player === mp) {
                        player = null
                        if (left > 1) startOne(app, f, left - 1)
                    }
                }
            }
            p.setOnErrorListener { mp, _, _ ->
                mp.release()
                synchronized(this) { if (player === mp) player = null }
                true
            }
            p.prepare()
            p.start()
            player = p
            true
        } catch (ex: Exception) {
            p.release()
            false
        }
    }

    @Synchronized
    fun stop() {
        player?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        player = null
    }
}
