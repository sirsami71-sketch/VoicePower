package com.voicepower

import android.Manifest
import android.content.Intent
import android.content.res.ColorStateList
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private var recorder: MediaRecorder? = null
    private var recordingEvent: PowerEvent? = null
    private var pendingRecord: PowerEvent? = null
    private var pendingPick: PowerEvent? = null
    private val rows = mutableMapOf<PowerEvent, View>()

    private val pickAudio =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val e = pendingPick
            if (uri != null && e != null) importFile(e, uri)
        }

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            val e = pendingRecord
            if (ok && e != null) startRecording(e)
            else toast("মাইক্রোফোনের অনুমতি ছাড়া রেকর্ড করা যাবে না")
        }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startEngine() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val list = findViewById<LinearLayout>(R.id.list)
        for (e in PowerEvent.values()) {
            val row = layoutInflater.inflate(R.layout.item_event, list, false)
            rows[e] = row
            list.addView(row)
            bind(e, row)
        }

        findViewById<Button>(R.id.btnBattery).setOnClickListener { openBatterySettings() }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startEngine()
        }
    }

    override fun onResume() {
        super.onResume()
        val ok = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        findViewById<Button>(R.id.btnBattery).text =
            if (ok) "✅ ব্যাটারি অপ্টিমাইজেশন বন্ধ আছে" else getString(R.string.battery_opt)
    }

    override fun onStop() {
        if (recordingEvent != null) stopRecording()
        super.onStop()
    }

    override fun onDestroy() {
        VoicePlayer.stop()
        super.onDestroy()
    }

    private fun startEngine() {
        ContextCompat.startForegroundService(this, Intent(this, PowerService::class.java))
        askBatteryOnce()
    }

    /** প্রথমবার খুললে একবারই সিস্টেমের ব্যাটারি-অপ্টিমাইজেশন ডায়ালগ দেখাবে, যাতে পরে আর অ্যাপ খুলতে না হয় */
    private fun askBatteryOnce() {
        val prefs = getSharedPreferences("voicepower", MODE_PRIVATE)
        if (prefs.getBoolean("asked_battery", false)) return
        if (getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)) return
        prefs.edit().putBoolean("asked_battery", true).apply()
        openBatterySettings()
    }

    private fun bind(e: PowerEvent, row: View) {
        row.findViewById<TextView>(R.id.title).text = e.title
        row.findViewById<TextView>(R.id.hint).text = e.hint
        row.findViewById<TextView>(R.id.icon).apply {
            text = iconFor(e)
            backgroundTintList = ColorStateList.valueOf(
                ColorUtils.setAlphaComponent(ContextCompat.getColor(this@MainActivity, colorFor(e)), 0x33)
            )
        }

        row.findViewById<MaterialSwitch>(R.id.enabled).apply {
            isChecked = VoiceStore.isEnabled(this@MainActivity, e)
            setOnCheckedChangeListener { _, checked ->
                VoiceStore.setEnabled(this@MainActivity, e, checked)
            }
        }

        row.findViewById<Button>(R.id.btnRecord).setOnClickListener { toggleRecord(e) }
        row.findViewById<Button>(R.id.btnPick).setOnClickListener {
            pendingPick = e
            pickAudio.launch(arrayOf("audio/*"))
        }
        row.findViewById<Button>(R.id.btnPlay).setOnClickListener {
            if (!VoicePlayer.play(this, e)) toast("এই ইভেন্টের জন্য আগে ভয়েস দিন")
        }
        row.findViewById<Button>(R.id.btnDelete).setOnClickListener {
            VoicePlayer.stop()
            VoiceStore.clear(this, e)
            refresh(e)
        }
        refresh(e)
    }

    private fun refresh(e: PowerEvent) {
        val row = rows[e] ?: return
        val has = VoiceStore.hasVoice(this, e)
        row.findViewById<TextView>(R.id.status).apply {
            text = if (has) "✅ ভয়েস সেট করা আছে" else "⚠️ ভয়েস নেই — রেকর্ড করুন বা ফাইল দিন"
            setTextColor(ContextCompat.getColor(this@MainActivity, if (has) R.color.green else R.color.amber))
        }
        val recording = recordingEvent == e
        row.findViewById<MaterialButton>(R.id.btnRecord).apply {
            text = if (recording) "⏹ থামান" else "🎙 রেকর্ড"
            backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this@MainActivity, if (recording) R.color.red else R.color.primary)
            )
        }
        val done = PowerEvent.values().count { VoiceStore.hasVoice(this, it) }
        findViewById<TextView>(R.id.summary).text = "🎙 ভয়েস সেট: $done/${PowerEvent.values().size}"
    }

    private fun iconFor(e: PowerEvent) = when (e) {
        PowerEvent.CONNECTED -> "⚡"
        PowerEvent.DISCONNECTED -> "🔌"
        PowerEvent.LEVEL_80 -> "🔋"
        PowerEvent.FULL -> "💯"
        PowerEvent.LOW -> "⚠️"
    }

    private fun colorFor(e: PowerEvent) = when (e) {
        PowerEvent.CONNECTED -> R.color.green
        PowerEvent.DISCONNECTED -> R.color.amber
        PowerEvent.LEVEL_80 -> R.color.cyan
        PowerEvent.FULL -> R.color.purple
        PowerEvent.LOW -> R.color.red
    }

    // ---------- রেকর্ডিং ----------

    private fun toggleRecord(e: PowerEvent) {
        when {
            recordingEvent == e -> stopRecording()
            recordingEvent != null -> toast("আগে চলমান রেকর্ডিং থামান")
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED -> startRecording(e)
            else -> {
                pendingRecord = e
                micPermission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun startRecording(e: PowerEvent) {
        VoicePlayer.stop()
        val tmp = VoiceStore.tempFile(this, e)
        try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100)
            r.setAudioEncodingBitRate(96000)
            r.setOutputFile(tmp.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            recordingEvent = e
            toast("রেকর্ডিং চলছে… কথা বলুন")
        } catch (ex: Exception) {
            recorder?.release()
            recorder = null
            recordingEvent = null
            tmp.delete()
            toast("রেকর্ড শুরু করা যায়নি")
        }
        refresh(e)
    }

    private fun stopRecording() {
        val e = recordingEvent ?: return
        val r = recorder
        val tmp = VoiceStore.tempFile(this, e)
        recorder = null
        recordingEvent = null
        try {
            r?.stop()
            r?.release()
            if (VoiceStore.install(this, e, tmp)) toast("ভয়েস সেভ হয়েছে")
            else toast("ভয়েস সেভ করা যায়নি")
        } catch (ex: RuntimeException) {
            // খুব ছোট রেকর্ডিং হলে stop() ব্যর্থ হয়
            r?.release()
            tmp.delete()
            toast("রেকর্ডিং খুব ছোট ছিল, আবার চেষ্টা করুন")
        }
        refresh(e)
    }

    // ---------- ফাইল থেকে ----------

    private fun importFile(e: PowerEvent, uri: Uri) {
        val tmp = VoiceStore.tempFile(this, e)
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { out -> input.copyTo(out) }
            } ?: throw IllegalStateException("open failed")
            if (VoiceStore.install(this, e, tmp)) toast("ভয়েস যোগ হয়েছে")
            else toast("ফাইল সেভ করা যায়নি")
        } catch (ex: Exception) {
            tmp.delete()
            toast("ফাইলটি পড়া যায়নি")
        }
        refresh(e)
    }

    // ---------- ব্যাটারি অপ্টিমাইজেশন ----------

    private fun openBatterySettings() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("ইতিমধ্যে বন্ধ করা আছে ✅")
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (ex: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
