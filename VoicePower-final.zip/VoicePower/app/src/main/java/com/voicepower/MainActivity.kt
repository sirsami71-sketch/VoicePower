package com.voicepower

import android.Manifest
import android.content.Intent
import android.content.res.ColorStateList
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import com.google.firebase.messaging.FirebaseMessaging
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private var recorder: MediaRecorder? = null
    private var recordingEvent: PowerEvent? = null
    private var pendingRecord: PowerEvent? = null
    private var pendingPick: PowerEvent? = null
    private val rows = mutableMapOf<PowerEvent, View>()

    private val pickAudio =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val e = pendingPick
            if (uri != null && e != null) importFile(e, uri)
        }

    private var onServiceAccountPicked: (() -> Unit)? = null

    private val pickServiceAccount =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@registerForActivityResult
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                if (RemotePush.isValidServiceAccount(text)) {
                    RemotePush.setServiceAccount(this, text)
                    toast("✅ ফাইল বসেছে")
                    onServiceAccountPicked?.invoke()
                } else toast("এটা সঠিক সার্ভিস অ্যাকাউন্ট ফাইল না")
            } catch (ex: Exception) {
                toast("ফাইল পড়া যায়নি")
            }
        }

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            val e = pendingRecord
            if (ok && e != null) startRecording(e)
            else toast("মাইক্রোফোনের অনুমতি ছাড়া রেকর্ড করা যাবে না")
        }

    private val btPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { askBatteryOnce() }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startEngine() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // অ্যাপ খোলা থাকলে ফোনের ভলিউম বাটন মিডিয়া (ভয়েস) ভলিউম বাড়াবে-কমাবে
        volumeControlStream = AudioManager.STREAM_MUSIC
        findViewById<View>(R.id.btnSettings).setOnClickListener { showSettings() }

        val list = findViewById<LinearLayout>(R.id.list)
        for (e in PowerEvent.values()) {
            val row = layoutInflater.inflate(R.layout.item_event, list, false)
            rows[e] = row
            list.addView(row)
            bind(e, row)
        }

        findViewById<Button>(R.id.btnBattery).setOnClickListener { openBatterySettings() }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startEngine()
        }
    }

    override fun onResume() {
        super.onResume()
        val ok = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        findViewById<Button>(R.id.btnBattery).text =
            if (ok) "✅ ব্যাটারি অপ্টিমাইজেশন বন্ধ আছে" else getString(R.string.battery_opt)
    }

    override fun onStop() {
        if (recordingEvent != null) stopRecording()
        super.onStop()
    }

    override fun onDestroy() {
        VoicePlayer.stop()
        super.onDestroy()
    }

    private fun startEngine() {
        ContextCompat.startForegroundService(this, Intent(this, PowerService::class.java))
        // ব্লুটুথ ডিভাইস কানেক্ট ধরার জন্য Android 12+ এ এই অনুমতি লাগে
        if (Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
            != PackageManager.PERMISSION_GRANTED
        ) {
            btPermission.launch(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            askBatteryOnce()
        }
    }

    /** প্রথমবার খুললে একবারই সিস্টেমের ব্যাটারি-অপ্টিমাইজেশন ডায়ালগ দেখাবে, যাতে পরে আর অ্যাপ খুলতে না হয় */
    private fun askBatteryOnce() {
        val prefs = getSharedPreferences("voicepower", MODE_PRIVATE)
        if (prefs.getBoolean("asked_battery", false)) return
        if (getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)) return
        prefs.edit().putBoolean("asked_battery", true).apply()
        openBatterySettings()
    }

    private fun bind(e: PowerEvent, row: View) {
        row.findViewById<TextView>(R.id.title).text = e.title
        row.findViewById<TextView>(R.id.hint).text = e.hint
        row.findViewById<TextView>(R.id.icon).apply {
            text = iconFor(e)
            backgroundTintList = ColorStateList.valueOf(
                ColorUtils.setAlphaComponent(ContextCompat.getColor(this@MainActivity, colorFor(e)), 0x33)
            )
        }

        row.findViewById<MaterialSwitch>(R.id.enabled).apply {
            isChecked = VoiceStore.isEnabled(this@MainActivity, e)
            setOnCheckedChangeListener { _, checked ->
                VoiceStore.setEnabled(this@MainActivity, e, checked)
            }
        }

        row.findViewById<Button>(R.id.btnRecord).setOnClickListener { toggleRecord(e) }
        row.findViewById<Button>(R.id.btnPick).setOnClickListener {
            pendingPick = e
            pickAudio.launch(arrayOf("audio/*"))
        }
        row.findViewById<Button>(R.id.btnPlay).setOnClickListener {
            if (!VoicePlayer.play(this, e)) toast("এই ইভেন্টের জন্য আগে ভয়েস দিন")
        }
        row.findViewById<Button>(R.id.btnDelete).setOnClickListener {
            VoicePlayer.stop()
            VoiceStore.clear(this, e)
            refresh(e)
        }
        refresh(e)
    }

    private fun refresh(e: PowerEvent) {
        val row = rows[e] ?: return
        val has = VoiceStore.hasVoice(this, e)
        row.findViewById<TextView>(R.id.status).apply {
            text = if (has) "✅ ভয়েস সেট করা আছে" else "⚠️ ভয়েস নেই — রেকর্ড করুন বা ফাইল দিন"
            setTextColor(ContextCompat.getColor(this@MainActivity, if (has) R.color.green else R.color.amber))
        }
        val recording = recordingEvent == e
        row.findViewById<MaterialButton>(R.id.btnRecord).apply {
            text = if (recording) "⏹ থামান" else "🎙 রেকর্ড"
            backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this@MainActivity, if (recording) R.color.red else R.color.primary)
            )
        }
        val done = PowerEvent.values().count { VoiceStore.hasVoice(this, it) }
        findViewById<TextView>(R.id.summary).text = "🎙 ভয়েস সেট: $done/${PowerEvent.values().size}"
    }

    private fun iconFor(e: PowerEvent) = when (e) {
        PowerEvent.CONNECTED -> "⚡"
        PowerEvent.DISCONNECTED -> "🔌"
        PowerEvent.LEVEL_80 -> "🔋"
        PowerEvent.FULL -> "💯"
        PowerEvent.LOW -> "⚠️"
        PowerEvent.BT_CONNECTED -> "⌚"
        PowerEvent.LOW10 -> "🪫"
        PowerEvent.LOW5 -> "🚨"
        PowerEvent.HOT -> "🌡"
        PowerEvent.HEADSET -> "🎧"
    }

    private fun colorFor(e: PowerEvent) = when (e) {
        PowerEvent.CONNECTED -> R.color.green
        PowerEvent.DISCONNECTED -> R.color.amber
        PowerEvent.LEVEL_80 -> R.color.cyan
        PowerEvent.FULL -> R.color.purple
        PowerEvent.LOW -> R.color.red
        PowerEvent.BT_CONNECTED -> R.color.cyan
        PowerEvent.LOW10 -> R.color.red
        PowerEvent.LOW5 -> R.color.red
        PowerEvent.HOT -> R.color.red
        PowerEvent.HEADSET -> R.color.cyan
    }

    // ---------- রেকর্ডিং ----------

    private fun toggleRecord(e: PowerEvent) {
        when {
            recordingEvent == e -> stopRecording()
            recordingEvent != null -> toast("আগে চলমান রেকর্ডিং থামান")
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED -> startRecording(e)
            else -> {
                pendingRecord = e
                micPermission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun startRecording(e: PowerEvent) {
        VoicePlayer.stop()
        val tmp = VoiceStore.tempFile(this, e)
        try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100)
            r.setAudioEncodingBitRate(96000)
            r.setOutputFile(tmp.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            recordingEvent = e
            toast("রেকর্ডিং চলছে… কথা বলুন")
        } catch (ex: Exception) {
            recorder?.release()
            recorder = null
            recordingEvent = null
            tmp.delete()
            toast("রেকর্ড শুরু করা যায়নি")
        }
        refresh(e)
    }

    private fun stopRecording() {
        val e = recordingEvent ?: return
        val r = recorder
        val tmp = VoiceStore.tempFile(this, e)
        recorder = null
        recordingEvent = null
        try {
            r?.stop()
            r?.release()
            if (VoiceStore.install(this, e, tmp)) {
                toast("ভয়েস সেভ হয়েছে — এখন শুনুন 🔊")
                VoicePlayer.play(this, e)
            } else {
                toast("ভয়েস সেভ করা যায়নি")
            }
        } catch (ex: RuntimeException) {
            // খুব ছোট রেকর্ডিং হলে stop() ব্যর্থ হয়
            r?.release()
            tmp.delete()
            toast("রেকর্ডিং খুব ছোট ছিল, আবার চেষ্টা করুন")
        }
        refresh(e)
    }

    // ---------- ফাইল থেকে ----------

    private fun importFile(e: PowerEvent, uri: Uri) {
        val tmp = VoiceStore.tempFile(this, e)
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { out -> input.copyTo(out) }
            } ?: throw IllegalStateException("open failed")
            if (VoiceStore.install(this, e, tmp)) {
                toast("ভয়েস যোগ হয়েছে — এখন শুনুন 🔊")
                VoicePlayer.play(this, e)
            } else {
                toast("ফাইল সেভ করা যায়নি")
            }
        } catch (ex: Exception) {
            tmp.delete()
            toast("ফাইলটি পড়া যায়নি")
        }
        refresh(e)
    }

    // ---------- সেটিংস: ভলিউম ও টেস্ট ----------

    private fun playSample() {
        val e = PowerEvent.values().firstOrNull { VoiceStore.hasVoice(this, it) }
        if (e == null) {
            toast("আগে কোনো একটা ইভেন্টে ভয়েস রেকর্ড করুন")
            return
        }
        VoicePlayer.play(this, e)
    }

    private fun showSettings() {
        val am = getSystemService(AudioManager::class.java)
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad, pad, 0)

        val label = TextView(this)
        label.textSize = 16f
        label.setTextColor(ContextCompat.getColor(this, R.color.text))

        val seek = SeekBar(this)
        seek.max = maxVol
        seek.progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)

        fun updateLabel() {
            label.text = "🔊 ভয়েসের ভলিউম: ${seek.progress * 100 / maxVol}%"
        }
        updateLabel()

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
                    updateLabel()
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { playSample() }
        })

        val hint = TextView(this)
        hint.textSize = 12f
        hint.setTextColor(ContextCompat.getColor(this, R.color.sub))
        hint.text = "স্লাইডার ছেড়ে দিলে ভয়েস বাজবে। এটা ফোনের মিডিয়া ভলিউম।"
        hint.setPadding(0, pad / 2, 0, pad / 2)

        val testBtn = Button(this)
        testBtn.text = "▶ টেস্ট করুন"
        testBtn.setOnClickListener { playSample() }

        box.addView(label)
        box.addView(seek)
        box.addView(hint)
        box.addView(testBtn)

        // ---- দূর থেকে নোটিফিকেশন (গুগল পুশ, অ্যাপ চালিয়ে রাখতে হয় না) ----
        fun title(t: String) = TextView(this).apply {
            textSize = 16f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text))
            text = t
            setPadding(0, pad, 0, pad / 3)
        }
        fun small(t: String) = TextView(this).apply {
            textSize = 12f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.sub))
            text = t
            setPadding(0, 0, 0, pad / 3)
        }

        val codeEdit = EditText(this)
        codeEdit.setSingleLine(true)
        codeEdit.setTextColor(ContextCompat.getColor(this, R.color.text))
        codeEdit.setText(RemotePush.code(this).ifBlank { RemotePush.randomCode() }.let {
            if (it.contains("-")) it else it.chunked(5).joinToString("-")
        })

        val newCode = Button(this)
        newCode.text = "🔄 নতুন কোড বানান (পুরোনো ফোন কেটে যাবে)"
        newCode.setOnClickListener {
            codeEdit.setText(RemotePush.randomCode())
            toast("নতুন কোড বসেছে। ঠিক আছে চাপলে চালু হবে।")
        }

        // গ্রহণকারী ফোন
        val recvSwitch = MaterialSwitch(this)
        recvSwitch.text = "📥 এই ফোনে বার্তা গ্রহণ করুন"
        recvSwitch.isChecked = RemotePush.receiveEnabled(this)

        val tokenView = TextView(this)
        tokenView.textSize = 11f
        tokenView.setTextIsSelectable(true)
        tokenView.setTextColor(ContextCompat.getColor(this, R.color.text))
        tokenView.text = RemotePush.myToken(this)

        val getToken = Button(this)
        getToken.text = "🪪 এই ফোনের পরিচয় (টোকেন) দেখান"
        getToken.setOnClickListener {
            try {
                FirebaseMessaging.getInstance().token.addOnSuccessListener { t ->
                    RemotePush.setMyToken(this, t)
                    tokenView.text = t
                    toast("চেপে ধরে কপি করুন")
                }.addOnFailureListener { toast("টোকেন পাওয়া যায়নি, ইন্টারনেট দেখুন") }
            } catch (ex: Exception) {
                toast("Firebase সেটআপ নেই (google-services.json)")
            }
        }

        // পাঠানোর ফোন
        val targetEdit = EditText(this)
        targetEdit.setSingleLine(true)
        targetEdit.hint = "ঘড়ির কাছের ফোনের টোকেন পেস্ট করুন"
        targetEdit.setTextColor(ContextCompat.getColor(this, R.color.text))
        targetEdit.setText(RemotePush.targetToken(this))

        val saStatus = TextView(this)
        saStatus.textSize = 12f
        saStatus.setTextColor(ContextCompat.getColor(this, R.color.sub))
        fun refreshSa() {
            val pid = RemotePush.projectId(this)
            saStatus.text = if (pid.isBlank()) "সার্ভিস অ্যাকাউন্ট ফাইল: নেই" else "সার্ভিস অ্যাকাউন্ট ফাইল: ✅ ($pid)"
        }
        refreshSa()
        onServiceAccountPicked = { refreshSa() }

        val pickSa = Button(this)
        pickSa.text = "🔑 সার্ভিস অ্যাকাউন্ট ফাইল বসান"
        pickSa.setOnClickListener { pickServiceAccount.launch(arrayOf("application/json", "text/plain", "*/*")) }

        val remoteTest = Button(this)
        remoteTest.text = "📤 টেস্ট বার্তা পাঠান"
        remoteTest.setOnClickListener {
            val raw = codeEdit.text.toString()
            if (!RemotePush.isValid(raw)) {
                toast("কোড কমপক্ষে ১৬ অক্ষরের হতে হবে")
                return@setOnClickListener
            }
            RemotePush.setCode(this, raw)
            RemotePush.setTargetToken(this, targetEdit.text.toString())
            if (!RemotePush.canSend(this)) {
                toast("টোকেন আর সার্ভিস অ্যাকাউন্ট ফাইল দুটোই লাগবে")
                return@setOnClickListener
            }
            RemotePush.send(this, "ভয়েস পাওয়ার টেস্ট", "এই বার্তা এলে সব ঠিক আছে")
            toast("পাঠানো হয়েছে")
        }

        box.addView(title("🔐 ফোন পেয়ারিং (দূর থেকে নোটিফিকেশন)"))
        box.addView(small("দুই ফোনে একই গোপন কোড বসান। কোড ছাড়া কোনো ফোন বার্তা পড়তে বা পাঠাতে পারবে না। কাউকে দেবেন না। কোড ফাঁকা থাকলে বন্ধ।"))
        box.addView(codeEdit)
        box.addView(newCode)
        box.addView(title("📥 ঘড়ির কাছের ফোন (গ্রহণকারী)"))
        box.addView(small("এই ফোনে গ্রহণ চালু করুন, তারপর টোকেন কপি করে চার্জের ফোনে বসান। অ্যাপ ব্যাকগ্রাউন্ডে চালু রাখতে হয় না, গুগলের পুশে সিস্টেম নিজে জাগায়।"))
        box.addView(recvSwitch)
        box.addView(getToken)
        box.addView(tokenView)
        box.addView(title("📤 চার্জের ফোন (প্রেরক)"))
        box.addView(small("গ্রহণকারী ফোনের টোকেন আর Firebase-এর সার্ভিস অ্যাকাউন্ট ফাইল দিন। ফাইলটা শুধু এই ফোনেই থাকে, কাউকে পাঠাবেন না।"))
        box.addView(targetEdit)
        box.addView(pickSa)
        box.addView(saStatus)
        box.addView(remoteTest)

        val scroll = android.widget.ScrollView(this)
        scroll.addView(box)

        AlertDialog.Builder(this)
            .setTitle("⚙️ সেটিংস")
            .setView(scroll)
            .setPositiveButton("ঠিক আছে") { _, _ ->
                val raw = codeEdit.text.toString()
                if (RemotePush.isValid(raw)) RemotePush.setCode(this, raw)
                else if (normalizeBlank(raw)) RemotePush.setCode(this, "")
                else toast("কোড ছোট, সেভ হয়নি")
                RemotePush.setReceive(this, recvSwitch.isChecked)
                RemotePush.setTargetToken(this, targetEdit.text.toString())
            }
            .show()
    }

    // ---------- ব্যাটারি অপ্টিমাইজেশন ----------

    private fun openBatterySettings() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("ইতিমধ্যে বন্ধ করা আছে ✅")
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (ex: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun normalizeBlank(raw: String) = RemotePush.normalize(raw).isEmpty()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
