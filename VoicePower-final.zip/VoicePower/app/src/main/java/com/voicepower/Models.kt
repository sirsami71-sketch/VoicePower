package com.voicepower

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.PowerManager
import java.io.File

enum class PowerEvent(val key: String, val title: String, val hint: String) {
    CONNECTED("connected", "চার্জার লাগালে", "চার্জার লাগানোর সাথে সাথে বাজবে"),
    DISCONNECTED("disconnected", "চার্জার খুললে", "চার্জার খোলার সাথে সাথে বাজবে"),
    LEVEL_80("level80", "ব্যাটারি ৮০% হলে", "চার্জ দেওয়ার সময় ৮০% ছুঁলে বাজবে"),
    FULL("full", "ব্যাটারি ১০০% হলে", "চার্জ দেওয়ার সময় ফুল হলে বাজবে"),
    LOW("low20", "ব্যাটারি ২০% এ নামলে", "চার্জ ছাড়া অবস্থায় ২০% বা কমে নামলে বাজবে"),
    BT_CONNECTED("btconnected", "ব্লুটুথ ডিভাইস কানেক্ট হলে", "ঘড়ি/ডিভাইস কানেক্ট হলে পপআপ আসবে, বন্ধ না করা পর্যন্ত বাজতে থাকবে")
}

object VoiceStore {
    private const val PREFS = "voicepower"

    private fun dir(ctx: Context): File =
        File(ctx.filesDir, "voices").apply { mkdirs() }

    fun file(ctx: Context, e: PowerEvent): File = File(dir(ctx), "${e.key}.m4a")

    fun tempFile(ctx: Context, e: PowerEvent): File = File(dir(ctx), "${e.key}.tmp")

    fun hasVoice(ctx: Context, e: PowerEvent): Boolean =
        file(ctx, e).let { it.exists() && it.length() > 0 }

    /** পুরোনো ভয়েসের জায়গায় নতুন ভয়েস বসায় */
    fun install(ctx: Context, e: PowerEvent, tmp: File): Boolean {
        val target = file(ctx, e)
        target.delete()
        return tmp.renameTo(target)
    }

    fun clear(ctx: Context, e: PowerEvent) {
        file(ctx, e).delete()
    }

    fun isEnabled(ctx: Context, e: PowerEvent): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(e.key, true)

    fun setEnabled(ctx: Context, e: PowerEvent, enabled: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(e.key, enabled).apply()
    }
}

object VoicePlayer {
    private var player: MediaPlayer? = null

    @Synchronized
    fun play(ctx: Context, e: PowerEvent): Boolean {
        val f = VoiceStore.file(ctx.applicationContext, e)
        if (!f.exists() || f.length() == 0L) return false
        stop()
        val p = MediaPlayer()
        return try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            // স্ক্রিন বন্ধ/লক থাকলেও যেন ভয়েস শেষ পর্যন্ত বাজে
            p.setWakeMode(ctx.applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(f.absolutePath)
            p.setOnCompletionListener { mp ->
                mp.release()
                synchronized(this) { if (player === mp) player = null }
            }
            p.setOnErrorListener { mp, _, _ ->
                mp.release()
                synchronized(this) { if (player === mp) player = null }
                true
            }
            p.prepare()
            p.start()
            player = p
            true
        } catch (ex: Exception) {
            p.release()
            false
        }
    }

    @Synchronized
    fun stop() {
        player?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        player = null
    }
}
